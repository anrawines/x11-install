// ==UserScript==
// @name        Remove All Rounded Corners (Aggressive)
// @namespace   UserScripts
// @match       *://*/*
// @grant       none
// @run-at      document-start
// ==/UserScript==

(function() {
    const css = `
        *, *::before, *::after {
            border-radius: 0px !important;
        }
    `;

    // 1. Inject into the main document
    const style = document.createElement('style');
    style.textContent = css;
    document.documentElement.appendChild(style);

    // 2. Function to handle Shadow DOMs
    function processShadowRoots(root) {
        root.querySelectorAll('*').forEach(el => {
            if (el.shadowRoot) {
                if (!el.shadowRoot.querySelector('.no-radius-style')) {
                    const s = document.createElement('style');
                    s.className = 'no-radius-style';
                    s.textContent = css;
                    el.shadowRoot.appendChild(s);
                }
                processShadowRoots(el.shadowRoot);
            }
        });
    }

    // 3. Watch for new elements (for dynamic sites like Gemini)
    const observer = new MutationObserver(() => {
        processShadowRoots(document);
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });
})();