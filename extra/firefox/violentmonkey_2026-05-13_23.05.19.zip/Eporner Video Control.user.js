// ==UserScript==
// @name         Eporner Video Control
// @namespace    http://tampermonkey.net/
// @version      1.9
// @description  Automatically unmute, set volume to 100%, set video quality to 480p, and simulate a click on the video element to start playback on Eporner. Play video by pressing the spacebar after the site has fully loaded.
// @author       Your Name
// @match        https://*.eporner.com/video-*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    // Wait for the page to load
    window.addEventListener('load', function () {
        // Function to unmute the video
        const unmuteVideo = () => {
            const video = document.querySelector('video');
            if (video) {
                video.muted = false;
                console.log('Video is unmuted.');
            } else {
                console.error('Video element not found.');
            }
        };

        // Function to set video quality to 480p
        const setQualityTo480p = () => {
            const qualityButton = document.querySelector('.vjs-menu-button.vjs-menu-button-popup.vjs-control.vjs-button.vjs-icon-hd');
            if (qualityButton) {
                qualityButton.click(); // Open the quality menu

                // Wait for the quality menu to appear
                setTimeout(() => {
                    const qualityOptions = document.querySelectorAll('.vjs-menu-item');
                    if (qualityOptions) {
                        // Find the 480p option
                        const quality480p = Array.from(qualityOptions).find(option => option.textContent.trim() === '480p');
                        if (quality480p) {
                            quality480p.click(); // Select 480p
                            console.log('Video quality set to 480p.');
                        } else {
                            console.error('480p option not found.');
                        }
                    } else {
                        console.error('Quality options not found.');
                    }
                }, 500); // Adjust delay if needed
            } else {
                console.error('Quality button not found.');
            }
        };

        // Function to play the video
        const playVideo = () => {
            const video = document.querySelector('EPvideo');
            if (video) {
                video.play().then(() => {
                    console.log('Video is playing.');
                }).catch((error) => {
                    console.error('Error playing video:', error);
                });
            } else {
                console.error('Video element not found.');
            }
        };

        // Function to set volume to 100%
        const setVolumeToMax = () => {
            const video = document.querySelector('video');
            if (video) {
                video.volume = 1; // Set volume to 100%
                console.log('Volume set to 100%.');

                // Update the volume control UI if necessary
                const volumeLevel = document.querySelector('.vjs-volume-level');
                if (volumeLevel) {
                    volumeLevel.style.width = '100%';
                    console.log('Volume control UI updated to 100%.');
                }
            } else {
                console.error('Video element not found.');
            }
        };

        // Function to simulate a click on the video element
        const simulateVideoClick = () => {
            const video = document.querySelector('EPvideo');
            if (video) {
                // Create a click event
                const clickEvent = new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                    view: window,
                });

                // Dispatch the click event on the video element
                video.dispatchEvent(clickEvent);
                console.log('Simulated click on the video element.');
            } else {
                console.error('Video element not found.');
            }
        };

        // Wait for the video player to initialize
        const waitForPlayer = setInterval(() => {
            const video = document.querySelector('video');
            if (video && video.readyState > 0) { // Check if video is ready
                clearInterval(waitForPlayer);

                // Unmute the video
                unmuteVideo();

                // Set volume to 100%
                setVolumeToMax();

                // Set quality to 480p
                setQualityTo480p();

                // Simulate a click on the video element
                simulateVideoClick();

                // Add spacebar event listener to play/pause the video
                document.addEventListener('keydown', (event) => {
                    if (event.code === 'Space') {
                        event.preventDefault(); // Prevent default spacebar behavior (scrolling)
                        if (video.paused) {
                            playVideo();
                        } else {
                            video.pause();
                            console.log('Video is paused.');
                        }
                    }
                });

                console.log('Press the spacebar to play/pause the video.');
            }
        }, 500); // Check every 500ms
    });
})();