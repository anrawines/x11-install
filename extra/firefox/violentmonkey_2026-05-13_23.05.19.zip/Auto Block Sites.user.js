// ==UserScript==
// @name Auto Block Sites
// @match *://*.shopee.*/*
// @run-at document-start
// ==/UserScript==

location.replace("about:blank");