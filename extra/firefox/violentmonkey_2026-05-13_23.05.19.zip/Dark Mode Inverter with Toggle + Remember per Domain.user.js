// ==UserScript==
// @name         Dark Mode Inverter with Toggle + Remember per Domain
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Invert websites with a toggle button, remember per domain
// @author       You
// @match        *://*/*
// @exclude      https://*.ttvnw.*/
// @exclude      https://*.playlist.ttvnw.*/
// @exclude      https://*.twitch.*/*
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const domain = location.hostname;
  const storageKey = 'darkModeInverter:' + domain;
  if (document.getElementById('darkModeToggleContainer')) return;

  let darkEnabled = localStorage.getItem(storageKey) === 'true';

  // More sophisticated dark mode styles
  const style = document.createElement('style');
  style.id = 'darkModeInverter';

  style.textContent = `
    /* Method 1: Smart inversion (better than simple invert) */
    html:not([data-darkmode-ignore]) {
      background: #0d1117 !important;
      color: #e6edf3 !important;
    }

    html:not([data-darkmode-ignore]) * {
      background-color: inherit !important;
      color: inherit !important;
      border-color: #30363d !important;
    }

    /* Don't invert images, but dim them */
    html:not([data-darkmode-ignore]) img,
    html:not([data-darkmode-ignore]) video,
    html:not([data-darkmode-ignore]) canvas,
    html:not([data-darkmode-ignore]) iframe {
      filter: brightness(0.8) contrast(1.1) !important;
      opacity: 0.9 !important;
    }

    /* Better link colors */
    html:not([data-darkmode-ignore]) a {
      color: #58a6ff !important;
    }

    /* Fix inputs */
    html:not([data-darkmode-ignore]) input,
    html:not([data-darkmode-ignore]) textarea,
    html:not([data-darkmode-ignore]) select {
      background: #161b22 !important;
      color: #e6edf3 !important;
      border: 1px solid #30363d !important;
    }

    /* Scrollbar styling */
    html:not([data-darkmode-ignore]) ::-webkit-scrollbar {
      width: 8px;
    }

    html:not([data-darkmode-ignore]) ::-webkit-scrollbar-track {
      background: #0d1117;
    }

    html:not([data-darkmode-ignore]) ::-webkit-scrollbar-thumb {
      background: #30363d;
      border-radius: 3px;
    }

    /* Ensure our button stays on top of EVERYTHING */
    #darkModeToggleContainer {
      z-index: 2147483647 !important;
    }
    #darkModeToggleHandle {
      z-index: 2147483647 !important;
    }
  `;

  // Enhanced toggle with guaranteed visibility - BOTTOM LEFT POSITION
  const container = document.createElement('div');
  container.id = 'darkModeToggleContainer';

  const handle = document.createElement('div');
  handle.id = 'darkModeToggleHandle';
  handle.textContent = darkEnabled ? 'LIGHT' : 'DARK';
  handle.title = 'Toggle Dark Mode (Ctrl+Shift+D)';

  // Handle styles for LEFT side
  Object.assign(handle.style, {
    width: '25px',  // Slightly smaller for bottom position
    height: '70px', // Slightly shorter for bottom position
    background: 'linear-gradient(135deg, #5c5c5c 0%, #5c5c5c 100%)',
    borderRadius: '0 12px 12px 0',  // Rounded on RIGHT side for left positioning
    display: 'flex !important',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    marginLeft: '0px',
    color: '#FFFFFF',
    fontSize: '12px',
    writingMode: 'vertical-rl',
    textOrientation: 'mixed',
    userSelect: 'none',
    fontWeight: '900',
    transition: 'all 0.3s ease',
    boxShadow: '0 0 20px rgba(255, 0, 0, 0.7), 0 0 10px rgba(255, 255, 255, 0.6)',
    border: '3px solid #FFFFFF',
    borderLeft: 'none',  // Remove left border for left side
    textShadow: '2px 2px 4px rgba(0,0,0,0.8)',
    letterSpacing: '2px',
    zIndex: '2147483647 !important',
    position: 'relative',
    opacity: '1 !important',
    visibility: 'visible !important'
  });

  // Container styles for BOTTOM LEFT position
  Object.assign(container.style, {
    position: 'fixed !important',
    bottom: '60px !important',    // 20px from bottom dont forget change position in ensureVisibility
    left: '0px !important',       // 0px from left
    right: 'auto !important',     // Disable right positioning
    top: 'auto !important',       // Disable top positioning
    transform: 'none !important', // No transform needed
    zIndex: '2147483647 !important',
    display: 'flex !important',
    alignItems: 'center',
    opacity: '0.9 !important',    // Slightly transparent when not hovering
    visibility: 'visible !important',
    transition: 'all 0.3s ease',
    margin: '0 !important',
    padding: '0 !important',
    pointerEvents: 'auto !important'
  });

  // Hover effects - slide out to the right
  container.onmouseenter = () => {
    handle.style.background = 'linear-gradient(135deg, #5c5c5c 0%, #5c5c5c 100%)';
    handle.style.transform = 'translateX(0px)';  // Slide right on hover
    handle.style.boxShadow = '0 0 25px rgba(255, 0, 0, 0.9)';
    container.style.opacity = '1 !important';
  };

  container.onmouseleave = () => {
    handle.style.background = 'linear-gradient(135deg, #5c5c5c 0%, #5c5c5c 100%)';
    handle.style.transform = 'translateX(0)';
    handle.style.boxShadow = '0 0 20px rgba(255, 0, 0, 0.7), 0 0 10px rgba(255, 255, 255, 0.6)';
    container.style.opacity = '0.9 !important';
  };

  function toggleDarkMode() {
    darkEnabled = !darkEnabled;

    if (darkEnabled) {
      document.head.appendChild(style);
      document.documentElement.setAttribute('data-dark-mode', 'true');
      handle.textContent = 'LIGHT';
      handle.style.background = 'linear-gradient(135deg, #5c5c5c 0%, #5c5c5c 100%)';
      handle.style.boxShadow = '0 0 20px rgba(38, 11, 22, 0.7), 0 0 10px rgba(255, 255, 255, 0.6)';
    } else {
      style.remove();
      document.documentElement.removeAttribute('data-dark-mode');
      handle.textContent = 'DARK';
      handle.style.background = 'linear-gradient(135deg, #5c5c5c 0%, #5e5c5c 100%)';
      handle.style.boxShadow = '0 0 20px rgba(38, 11, 22, 0.7), 0 0 10px rgba(255, 255, 255, 0.6)';
    }

    localStorage.setItem(storageKey, darkEnabled);
  }

  handle.onclick = toggleDarkMode;

  // Keyboard shortcut
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && e.key === 'D') {
      e.preventDefault();
      toggleDarkMode();
    }
  });

  // Apply initial state
  if (darkEnabled) {
    document.head.appendChild(style);
    document.documentElement.setAttribute('data-dark-mode', 'true');
    handle.textContent = 'LIGHT';
    handle.style.background = 'linear-gradient(135deg, #5c5c5c 0%, #5c5c5c 100%)';
    handle.style.boxShadow = '0 0 20px rgba(38, 11, 22, 0.7), 0 0 10px rgba(255, 255, 255, 0.6)';
  }

  // Add to page
  container.appendChild(handle);
  document.body.appendChild(container);

  // Force it to stay on top and visible
  const ensureVisibility = () => {
    container.style.zIndex = '2147483647';
    handle.style.zIndex = '2147483647';

    container.style.visibility = 'visible';
    container.style.display = 'flex';
    container.style.opacity = '0.9';
    handle.style.visibility = 'visible';
    handle.style.display = 'flex';
    handle.style.opacity = '1';

    // Force bottom-left positioning
    container.style.position = 'fixed';
    container.style.bottom = '60px';
    container.style.left = '0';
    container.style.right = 'auto';
    container.style.top = 'auto';
    container.style.transform = 'none';
  };

  ensureVisibility();
  setTimeout(ensureVisibility, 100);
  setTimeout(ensureVisibility, 500);

  // Aggressive observer to keep button visible and in place
  const observer = new MutationObserver(() => {
    if (container.parentNode !== document.body) {
      document.body.appendChild(container);
    }
    ensureVisibility();
  });
  observer.observe(document.body, { childList: true, subtree: true });
})();