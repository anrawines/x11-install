// ==UserScript==
// @name         Smart Video Speed Controller PRO
// @namespace    http://tampermonkey.net/
// @version      4.1
// @description  Smart per-site video speed with detection (live, shorts, music, normal)
// @match        *://*/*
// @exclude      /^https?:\/\/\w+\.youtube\.com\/live_chat.*$/
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_addValueChangeListener
// ==/UserScript==

(function() {
    'use strict';

    // ---------------- CONFIG ----------------
    const SPEED_INCREMENT = 0.1;
    const MIN_SPEED = 0.5;
    const MAX_SPEED = 3.0;
    const DEFAULT_SPEED = 1.0;

    const SITE_KEY = `speed_${location.hostname}`;

    // ---------------- HELPERS ----------------
    const getVideos = () => document.querySelectorAll('video');

    const saveSpeed = (speed) => GM_setValue(SITE_KEY, speed);
    const getSavedSpeed = () => parseFloat(GM_getValue(SITE_KEY, NaN));

    // ---------------- DETECTION ----------------
    function isLive(video) {
        return video.duration === Infinity ||
               location.pathname.includes('/live') ||
               document.querySelector('[aria-label*="live"], .live, .is-live');
    }

    // ---------------- SPEED APPLY ----------------
    function applySpeed(video) {
        if (video.dataset.smartSpeed) return;
        video.dataset.smartSpeed = "true";

        let saved = getSavedSpeed();
        let speed = !isNaN(saved) ? saved : DEFAULT_SPEED;

        const set = (s, persist = true) => {
            s = Math.max(MIN_SPEED, Math.min(MAX_SPEED, s));
            speed = s; // keep closure in sync
            video.playbackRate = s;
            if (persist) saveSpeed(s);
            showOSD(s);
        };

        video._setSpeed = set;

        const init = () => {
            if (isLive(video)) return;
            set(speed, false);
        };

        video.addEventListener('loadedmetadata', init);
        video.addEventListener('play', init);

        // Light enforcement (no spam)
        const interval = setInterval(() => {
            if (!document.contains(video)) return clearInterval(interval);
            if (isLive(video)) return;

            if (Math.abs(video.playbackRate - speed) > 0.05) {
                video.playbackRate = speed;
            }
        }, 2000);
    }

    function applyAll() {
        getVideos().forEach(applySpeed);
    }

    // ---------------- OSD ----------------
    function showOSD(text) {
        const existing = document.getElementById('speedOSD');
        if (existing) existing.remove();

        const osd = document.createElement('div');
        osd.id = 'speedOSD';
        osd.textContent = typeof text === "number"
            ? `▶ ${text.toFixed(2)}x`
            : text;

        osd.style.cssText = `
            position: fixed;
            bottom: 40px;
            right: 40px;
            background: rgba(0,0,0,0.75);
            color: #fff;
            padding: 10px 16px;
            border-radius: 12px;
            font-size: 15px;
            z-index: 999999;
            pointer-events: none;
            backdrop-filter: blur(6px);
        `;

        document.body.appendChild(osd);
        setTimeout(() => osd.remove(), 1200);
    }

    // ---------------- CONTROLS ----------------
    function handleKey(e) {
        if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName) ||
            document.activeElement.isContentEditable) return;

        const video = document.querySelector('video');
        if (!video || !video._setSpeed) return;

        let current = video.playbackRate;

        switch (e.code) {
            case 'ControlRight':
                video._setSpeed(current + SPEED_INCREMENT);
                e.preventDefault();
                break;
            case 'ShiftRight':
                video._setSpeed(current - SPEED_INCREMENT);
                e.preventDefault();
                break;
            case 'AltRight':
                video._setSpeed(DEFAULT_SPEED);
                e.preventDefault();
                break;
        }
    }

    document.addEventListener('keydown', handleKey);

    // ---------------- OBSERVER ----------------
    const observer = new MutationObserver(applyAll);
    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });

    // ---------------- SYNC ----------------
    GM_addValueChangeListener(SITE_KEY, (_, oldVal, newVal) => {
        if (newVal !== oldVal) {
            document.querySelectorAll('video').forEach(v => {
                if (v._setSpeed) v._setSpeed(parseFloat(newVal), false);
            });
        }
    });

    // ---------------- INIT ----------------
    applyAll();

})();