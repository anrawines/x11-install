// ==UserScript==
// @name         yt-dlp Python-Downloader
// @namespace    https://greasyfork.org/en/users/1462137-piknockyou
// @version      9.59
// @author       Piknockyou (vibe-coded)
// @license      AGPL-3.0
// @description  Unified yt-dlp downloader - generates cross-platform Python scripts for video, audio, subtitles
//
// ═══════════════════════════════════════════════════════════════
// SIMPLE SITES - Just add @match lines here, nothing else needed!
// ═══════════════════════════════════════════════════════════════
// @match        *://www.arte.tv/*/videos/*
// @match        *://www.dailymotion.com/*
// @match        *://www.facebook.com/*
// @match        *://www.instagram.com/*
// @match        *://www.reddit.com/*
// @match        *://soundcloud.com/*
// @match        *://www.tagesschau.de/*
// @match        *://www.tiktok.com/*
// @match        *://www.twitch.tv/*
// @match        *://twitter.com/*
// @match        *://vimeo.com/*
// @match        *://player.vimeo.com/*
// @match        *://www.youtube.com/*
// @match        *://youtube.com/*
// @match        *://m.youtube.com/*
// @match        *://music.youtube.com/*
// @match        *://x.com/*
//
// ═══════════════════════════════════════════════════════════════
// COMPLEX SITES - These need special extractors (defined below)
// ═══════════════════════════════════════════════════════════════
// @match        *://app.livestorm.co/*
// @icon         https://raw.githubusercontent.com/yt-dlp/yt-dlp/refs/heads/master/devscripts/logo.ico
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_cookie
// @grant        GM.cookie
// @connect      *
// @downloadURL https://update.greasyfork.org/scripts/562255/yt-dlp%20Python-Downloader.user.js
// @updateURL https://update.greasyfork.org/scripts/562255/yt-dlp%20Python-Downloader.meta.js
// ==/UserScript==
//
// ═══════════════════════════════════════════════════════════════
// CHANGELOG
// ═══════════════════════════════════════════════════════════════
// v9.59
// - Cleanup: Removed unused `desc` properties from OUTPUT_MODES, VIDEO_CODECS, AUDIO_CODECS, SUBTITLE_FORMATS
// - Cleanup: Removed dead `showCodecOption` variable from generatePythonScript()
// - Cleanup: Removed unused `_url`/`_filename` params from generateDownloadFunction()
// - Cleanup: Trimmed getComponentStates() to only compute properties consumed by callers
// - Cleanup: Removed unreachable .ytdlp-notification CSS from button shadow root (duplicate of notification shadow root)
//
// v9.58
// - Changed: Secret Extras is now a flyout submenu row ("⚙ OPTIONS") in the main context menu
// - Removed: Separate popup triggered by right-clicking Support button
// - Reuses existing submenu hover/positioning mechanics (DRY)
// - Support button tooltip updated (no longer mentions right-click)
//
// v9.57
// - Changed: Cookie API banner now lists Violentmonkey first (recommended), Tampermonkey second
//
// v9.56
// - Fixed: Cookie API banner now renders reliably (pure DOM creation, no innerHTML in shadow root)
// - Fixed: Export Cookies button now always triggers banner or export (was silently failing)
//
// v9.55
// - Changed: Cookie API unavailable error now shows large centered dismissible banner with setup instructions
// - Banner explains which userscript managers support GM_cookie and how to enable HttpOnly access
// - Replaces previous small red notification that was easy to miss
//
// v9.54
// - Fixed: Cookie export now works on Violentmonkey (GM_cookie is an object, not a function)
// - Fixed: Detection covers all three API styles: GM.cookie.list (promise), GM_cookie.list (object), GM_cookie() (legacy)
// - Added: @grant GM.cookie for promise-based API compatibility
//
// v9.53
// - Fixed: Notifications now truly render above the context menu (separate top-layer shadow host)
// - Notification shadow host appended after context menu host, both at z-index 2147483647
//
// v9.52
// - Fixed: Notifications (download started, cookie errors, etc.) now appear above the context menu
// - Was z-index 2147483645, context menu was 2147483647 — notifications were hidden behind it
//
// v9.51
// - Fixed: All generated scripts now check ffmpeg/ffprobe/mkvmerge upfront based on actual needs
// - Fixed: Audio-only --extract-audio no longer fails silently when ffmpeg missing (early check + clear error)
// - Fixed: ffprobe status only shown when file identification is actually needed (V+A or merge cases)
// - Fixed: ffmpeg checked early when needed for: extract-audio, combined-stream split, MP4 merge, FFmpeg fallback
//
// v9.50
// - Added: Cookie export via GM_cookie API (Netscape format for yt-dlp --cookies)
// - Added: "Auto Export Cookies" toggle in Secret Extras (exports alongside .py download)
// - Added: "Export Cookies" button in context menu (manual one-click export)
// - Added: Graceful fallback when GM_cookie API unavailable (older userscript managers)
//
// v9.49
// - Improved: ffprobe check now prints status line (OK/INFO) so user knows which identification tier will be used
// - DRY: Consistent tool check reporting for ffprobe alongside mkvmerge/ffmpeg
//
// v9.48
// - Fixed: Tier 2 format-ID probe now includes codec sort arg + audio codec filter (matches download call)
// - Without this, probe could resolve different format IDs than what was actually downloaded
//
// v9.47
// - Fixed: File identification no longer misclassifies audio-only .webm/.mp4 as video when ffprobe missing
// - Added: Two-tier identification: ffprobe (primary, fast, local) → yt-dlp format-ID probe (fallback)
// - Fixed: Phase 2 collect-then-assign loop prevents overwrite bug (two "video" files)
// - Added: probe_format_ids() helper queries yt-dlp for authoritative format-ID→type mapping
// - Added: match_format_id_from_filename() extracts format_id from temp filename pattern
//
// v9.46
// - Fixed: Python entry point now centralized for media mode (added once after generateDownloadFunction)
// - Removed per-branch entry points from generateDownloadFunction CASE 1/2/3/4
// - All generated scripts guaranteed to have entry point regardless of component/merge combination
//
// v9.45
// - Fixed: CASE 3 (no-merge) generated scripts now include entry point (if __name__ == "__main__": safe_main(main))
// - Scripts no longer open/close instantly when double-clicked on Windows
//
// v9.44
// - Fixed: Generated Python scripts no longer have duplicate main() entry point (was running twice)
// - Fixed: Removed unused codecArg, subsConvertArg, mergedExt from generateDownloadFunction
// - Cleanup: Removed unused error parameter from wait_for_exit() in generated Python (v9.8 claimed this was done)
// - Cleanup: Replaced comma operator with forEach for SVG attribute setting (linter compliance)
// - Cleanup: Fixed forEach callback return value warnings in 4 locations (linter compliance)
//
// v9.43
// - Fixed: UnboundLocalError on REFERER in all four generated main() functions (missing global declaration)
//
// v9.42
// - Fixed: Console no longer closes instantly on error (safe_main wrapper in all entry points)
// - Refactor: All Vimeo referer logic consolidated into dedicated VIMEO section (getVimeoReferer)
// - Changed: player.vimeo.com with no document.referrer now falls back to https://vimeo.com/
//
// v9.41
// - Fixed: Removed bad Vimeo URL conversion (player.vimeo.com caused embed-only error)
// - Fixed: getReferer() now uses document.referrer for player.vimeo.com (actual embedding page)
// - Added: resolve_vimeo_embed_referer() helper in generated Python (auto-detects or prompts)
// - Added: Embed-only probe + interactive URL prompt in all generated main() functions
//
// v9.40
// - Formatting
//
// v9.39
// - Fixed: Added YouTube subdomains (youtube.com, m.youtube.com, music.youtube.com) to @match + detection
// - Fixed: Generated Python now falls back to common YouTube cookie filenames automatically
// - Added: Referer hint for music.youtube.com in generated scripts
//
// v9.38
// - Refactor: DRY generated Python via shared helpers (require_ytdlp, get_cookies_arg, build_base_cmd)
// - Refactor: Updated all generated script modes to use helpers for yt-dlp checks + cookie handling
//
// v9.37
// - Cleanup: Removed unused componentType parameter from toggleMerge, toggleSeparate, buildComponentRow
// - Cleanup: Removed no-op sub_template variable (replaced with direct output_template reference)
//
// v9.36
// - Refactor: Replaced subprocess.run monkeypatch with explicit ytdlp_base() helper
// - Refactor: All 12 yt-dlp call sites now use ytdlp_base() for --restrict-filenames
//
// v9.35
// - Fixed: All yt-dlp calls now auto-include --restrict-filenames for ASCII-safe output
// - Fixed: Reverted .B template suffix (yt-dlp ignores it for Unicode stripping)
//
// v9.34
// - Fixed: Downloads no longer fail when title contains non-ASCII/Unicode characters (Facebook Persian, etc.)
// - Fixed: sanitize_filename now strips non-ASCII chars for cross-platform safety
// - Fixed: yt-dlp output template now uses .B restriction for ASCII-safe filenames
//
// v9.33
// - Fixed: Soundcloud Playlist downloads no longer overwrite files with same name
// - Added: Audio format selection (MP3/AAC/Opus) now available on all sites (tested on Soundcloud)
// - Changed: Filenames now include artist/uploader by default (Artist - Title [ID]) (tested on Soundcloud)
// - Improved: Tooltip/labels show chosen audio format on all sites
//
// v9.32
// - Fixed: MP4 merge now converts subtitles to mov_text format
// - Fixed: Accurate console message when using FFmpeg for MP4 (not "mkvmerge not found")
//
// v9.31
// - Added: "Prefer MP4" toggle in Secret Extras
// - MP4 output uses FFmpeg instead of mkvmerge
// - Warns about codec/subtitle compatibility in console
//
// v9.30
// - Added: Secret Extras menu (right-click Support button)
// - Added: "Include Video ID" toggle in Secret Extras (on by default)
//
// v9.29
// - Added: Ko-Fi support button in context menu
//
// v9.28
// - Fixed: Vimeo now works reliably by using player URL + referer bypass
//
// v9.27
// - Improved: Output naming now uses yt-dlp metadata (title + id) for better filenames (Instagram, etc.)
// - Keeps current page-title fallback if metadata lookup fails
//
// v9.26
// - Fixed: Dailymotion now works (requires --impersonate to bypass Cloudflare)
// - Added IMPERSONATE_SITES config for sites needing browser impersonation
//
// v9.25
// - Fixed: Audio codec filter quotes no longer break Python syntax
// - Uses escaped quotes in generated format strings
//
// v9.24
// - Added: More video quality options (4K, 1440p, 240p, 144p)
// - Added: Medium audio quality option
// - Added: Audio codec preference (AAC for H.264, Opus for VP9/AV1)
// - Improved codec matching for better compatibility
//
// v9.23
// - Added: "Formats" button to list all available formats for current video
// - Shows yt-dlp --list-formats output in terminal
//
// v9.22
// - Fixed: Format string now includes /best fallback for combined-stream sites
// - TikTok, Twitter etc. no longer fail with "format not available"
//
// v9.21
// - Fixed: Combined-stream detection now works in merge+separate mode (CASE 4)
// - Splits combined stream before merge phase, so merge gets proper inputs
//
// v9.20
// - Fixed: Combined-stream sites now strip audio from video when both are separate
// - Detection: if we requested 2 formats but got 1 file, it's a combined stream
// - Uses ffmpeg remux (no re-encoding) to strip audio track from video
// - Sites with separate streams (YouTube) are unaffected
//
// v9.19
// - Fixed: Video+Audio separate mode now extracts audio when site has combined streams
// - TikTok, Twitter, etc. now correctly produce both video and audio files
// - Uses ffmpeg stream copy (no re-encoding) when extracting audio from video
//
// v9.18
// - Fixed: Audio-only mode now uses --extract-audio for sites without separate streams
// - Uses yt-dlp's native post-processor (ffmpeg) - no re-encoding, stream copy
// - Works reliably on TikTok, Twitter, and other video-only sites
//
// v9.17
// - Fixed: Right-click menu now works on TikTok and other sites with aggressive event handling
// - Fixed: Uses window-level capture to bypass shadow DOM event routing issues
//
// v9.16
// - Fixed: Subtitle check now handles empty output (not just "has no subtitles" message)
//
// v9.15
// - Fixed: Single-component merge no longer creates duplicate when Separate also selected
// - Fixed: Both mkvmerge and FFmpeg paths check for duplicate output in Phase 4
//
// v9.14
// - Fixed: FFmpeg fallback now merges already-downloaded temp files (no double download)
// - Fixed: Added ffmpeg availability check when mkvmerge not found
//
// v9.13
// - Fixed: wait_for_exit() now accepts optional error parameter (was causing crashes)
//
// v9.12
// - Fixed: Audio-only .mp4 files (Twitter/X HLS) now correctly identified
// - Fixed: Uses format_id hint ("audio" in filename) for stream detection
// - Fixed: ffprobe now used for .mp4 files too (not just .webm)
//
// v9.11
// - Changed: Thumbnails mode keeps original format (webp/jpg) instead of converting to PNG
// - Changed: Cleaner thumbnail output messaging
//
// v9.10
// - Fixed: Thumbnails mode now downloads only the best thumbnail (not all 42 variants)
//
// v9.9
// - Added: Thumbnails Only mode - downloads all video thumbnails as PNG
//
// v9.8
// - Cleanup: Removed unused run_command() from generated Python scripts
// - Cleanup: Removed unused GM_setClipboard grant
// - Cleanup: Removed empty mouseleave handler
// - Cleanup: Removed unused active opacity/scale config
// - Cleanup: Simplified wait_for_exit() (removed unused error parameter)
// - Cleanup: Updated Python header version string
//
// v9.7
// - Fixed: Codec label no longer displays on non-YouTube sites (display-only bug)
// - Fixed: Tooltip now shows codec preference on YouTube for consistency
// - Fixed: Comments mode only uses YouTube extractor args on YouTube
// - Cleanup: Removed unused needsMerge from getComponentStates()
//
// v9.6
// - Fixed: Codec selection now works (removed shell quotes that broke Python string literals)
//
// v9.5
// - Fixed: Separate mode now correctly names video/audio files (was using invalid template syntax)
// - Fixed: No-merge case now uses temp files + identification like merge case
//
// v9.4
// - Fixed: Skip subtitle prompt when video has no subtitles available
// - Fixed: Video/audio quality now falls back to best available if requested quality unavailable
// - Fixed: Audio-only merge uses native audio extension instead of .mkv
//
// v9.3
// - Fixed: Submenus now close when hovering over a different component row
//
// v9.2
// - Fixed: Submenu no longer closes when moving mouse from row to submenu (bridged hover gap)
// - Fixed: Selected buttons (Merge/Sep) no longer turn gray on hover
//
// v9.1
// - Fixed: JavaScript booleans (true/false) now correctly converted to Python (True/False)
// - Fixed: Generated scripts now execute properly on all platforms
//
// v9.0
// - Complete rewrite: now generates Python scripts instead of batch files
// - Cross-platform: works on Windows, Mac, and Linux
// - Same functionality as v8.4 batch version
// - Python 3 required (pre-installed on Mac/Linux, install on Windows)
// - Uses only Python standard library (no pip packages needed)
//
// v8.4
// - Refactored: Sites now default to full mkvmerge flow (supports Separate)
// - Added: COMBINED_STREAM_SITES blacklist for sites without separate streams
// - Fixed: Reddit, Twitter, etc. now properly support Merge+Separate
// - Note: Add sites to COMBINED_STREAM_SITES if they fail with "format not available"
//
// v8.3
// - Fixed: Non-YouTube sites now use format with /best fallback
// - Fixed: Livestorm and other HLS sites work again (combined streams)
// - Fixed: Non-YouTube sites skip complex merge flow, use yt-dlp native merge
// - Note: Merge/Separate options still work for YouTube; non-YouTube gets best available
//
// v8.2
// - Changed: Error prompts now require Enter key (not any key) to close
// - Uses "set /p" instead of "pause" for consistent behavior
//
// v8.1
// - Fixed: Removed invalid %(lang)s placeholder from subtitle template
// - Fixed: Subtitle files now correctly named as filename.en.srt (not filename.NA.en.srt)
// - Note: yt-dlp automatically inserts language code before extension
//
// v8.0
// - Complete rewrite of batch generation for all merge/separate combinations
// - Fixed: Subtitle glob patterns now match actual downloaded files
// - Fixed: Separate file naming (no temp prefix in output names)
// - Fixed: Video/audio detection using ffprobe for ambiguous formats
// - Fixed: Selective cleanup - only deletes temp files, preserves separate copies
// - Fixed: All 64 combinations of V/A/S × None/Merge/Sep/Both now work correctly
// - Added: Proper language preservation in subtitle filenames
// - Added: Robust file identification with subroutine-based processing
//
// v7.10
// - Fixed: Merge ON now sets ALL components to Merge (user deselects unwanted)
// - Fixed: Merge OFF only removes from clicked component
// - Fixed: Auto-cleanup when only 1 merge remains
//
// v7.9
// - Fixed: Merge OFF now only removes merge from clicked component
// - Fixed: Other components keep their merge when one is deselected
// - Fixed: Auto-cleanup only when going from 2 merges to 1 (can't merge alone)
// - Fixed: Merge ON adds to clicked + other enabled components if first merge
//
// v7.8
// - Fixed: Merge is now a global toggle - on for all or off for all
// - Fixed: Clicking Merge OFF on any component removes merge from ALL
// - Fixed: Auto-removes merge when only 1 component remains with merge
// - Fixed: Audio was incorrectly included in merge when set to Separate only
//
// v7.7
// - Fixed: Merge button always clickable - clicking sets ALL to merge
// - Fixed: Merge persists on remaining components when one is set to None/Sep
// - Fixed: Merge auto-removes only when single component left with merge
//
// v7.6
// - Fixed: Subtitles no longer downloaded twice in separate mode
// - Fixed: Deactivating Merge on one deactivates Merge on ALL
// - Fixed: Merge button disabled when only one component is enabled
// - Fixed: Submenus now available even when None is selected
// - Fixed: Panel width fits content
//
// v7.5
// - Redesigned output modes: Merge and Separate are now independent toggles
// - Removed "Both" button - now click Merge AND Sep to get both behaviors
// - Clicking Merge auto-activates Merge for all other enabled components
// - Fixed: No longer crashes when only subs want merge but no media to merge into
// - Simplified case logic in batch generation
//
// v7.4
// - Fixed: Crash when subs=Both but no media being merged
// - Fixed: Single yt-dlp call for media+subs (no duplicate metadata fetch)
// - Improved needsMerge logic to require actual media track to merge
//
// v7.3
// - Fixed: Batch window now waits for user confirmation after mkvmerge
// - Fixed: Merge with subtitles no longer crashes
// - Fixed: "Both" mode now correctly creates merged + separate files
// - Restructured batch flow to always reach pause at end
//
// v7.2
// - Fixed: Subtitle-only mode now uses --skip-download correctly
// - Fixed: Merge/Both buttons disabled when only one component selected
// - Reordered output buttons: Merge/Separate/Both/None
// - Improved stability and error handling
//
// v7.1
// - Restructured menu: Video/Audio/Subtitle rows with inline output modes
// - Detail submenus open on hover (disabled if output=None)
// - Menu stays open until clicking outside (even after download)
// - Removed error message - just grays out download button
// - Original subtitle format now default and first in list
//
// v7.0
// - Complete redesign: unified Media Download menu
// - New output modes: None/Merge/Separate/Both for each component
// - Removed interactive console prompts (D/E/ALL/ALLS quick-picks)
// - Removed subtitle source selection (always fetches all available)
// - Subtitle language selection remains in .bat file
// - DRY: shared subtitle format options across all modes

(() => {
	// ═══════════════════════════════════════════════════════════════
	// SITE-SPECIFIC URL CONDITIONS (SPA Support)
	// ═══════════════════════════════════════════════════════════════
	const SITE_CONDITIONS = {
		"www.reddit.com": (url) => /\/r\/[^/]+\/comments\/[^/]+/.test(url),
	};

	// ═══════════════════════════════════════════════════════════════
	// COMPLEX SITES - Only define sites that need special URL extraction
	// ═══════════════════════════════════════════════════════════════
	const COMPLEX_SITES = {
		"app.livestorm.co": {
			cookieFile: "app.livestorm.co_cookies.txt",
			extractUrl: () => {
				const match = document.documentElement.innerHTML.match(
					/https:\\?\/\\?\/cdn\.livestorm\.co\\?\/[^"'\s]+\.m3u8[^"'\s]*/,
				);
				return match
					? { url: match[0].replace(/\\/g, "") }
					: { error: "Video URL not found. Make sure the video is loaded." };
			},
		},
	};

	// ═══════════════════════════════════════════════════════════════
	// COMBINED STREAM SITES - Sites that only have muxed video+audio
	// These sites don't support Separate mode (no individual streams)
	// Add hostname here if download fails with "format not available"
	// ═══════════════════════════════════════════════════════════════
	const COMBINED_STREAM_SITES = [
		"app.livestorm.co",
		"cdn.livestorm.co",
		// Add more sites here as needed, e.g.:
		// 'some-hls-only-site.com',
	];

	// ═══════════════════════════════════════════════════════════════
	// IMPERSONATE SITES - Sites that need --impersonate to bypass Cloudflare
	// These sites block requests without browser TLS fingerprinting
	// Requires curl_cffi: pip install "yt-dlp[curl-cffi]"
	// ═══════════════════════════════════════════════════════════════
	const IMPERSONATE_SITES = [
		"www.dailymotion.com",
		"dailymotion.com",
		// Add more sites here as needed
	];

	// Helper to check if current site needs impersonation
	const needsImpersonation = () =>
		IMPERSONATE_SITES.some(
			(site) =>
				window.location.hostname === site ||
				window.location.hostname.endsWith(`.${site}`),
		);

	// Sites that need a static referer header to bypass anti-bot protection
	const REFERER_SITES = {
		"music.youtube.com": "https://music.youtube.com/",
	};

	// ═══════════════════════════════════════════════════════════════
	// VIMEO — Referer resolution
	// Vimeo embed-only videos require the embedding page URL as --referer.
	// • player.vimeo.com: use document.referrer (the embedding page the
	//   browser navigated from), or fall back to https://vimeo.com/.
	// • vimeo.com / www.vimeo.com: no custom referer needed for public videos.
	// ═══════════════════════════════════════════════════════════════
	const getVimeoReferer = () => {
		if (window.location.hostname === "player.vimeo.com") {
			return document.referrer || "https://vimeo.com/";
		}
		return "";
	};

	// Helper to get referer for current site
	const getReferer = () => {
		const h = window.location.hostname;
		if (
			h === "vimeo.com" ||
			h === "www.vimeo.com" ||
			h === "player.vimeo.com"
		) {
			return getVimeoReferer();
		}
		return REFERER_SITES[h] || "";
	};

	// Helper to check if current site has combined streams only
	const isCombinedStreamSite = () =>
		COMBINED_STREAM_SITES.some(
			(site) =>
				window.location.hostname === site ||
				window.location.hostname.endsWith(`.${site}`),
		);

	//================================================================================
	// CONFIGURATION
	//================================================================================

	// ═══════════════════════════════════════════════════════════════
	// OUTPUT MODES - Merge and Separate are independent toggles
	// Internal values: 'none', 'merge', 'separate', 'merge-separate'
	// ═══════════════════════════════════════════════════════════════
	const OUTPUT_MODES = [
		{ id: "none", label: "None" },
		{ id: "merge", label: "Merge" },
		{ id: "separate", label: "Separate" },
		{ id: "merge-separate", label: "Merge+Sep" },
	];

	// Helper to check if output includes merge
	const hasMergeFlag = (output) =>
		output === "merge" || output === "merge-separate";
	const hasSeparateFlag = (output) =>
		output === "separate" || output === "merge-separate";
	const isEnabled = (output) => output !== "none";

	// ═══════════════════════════════════════════════════════════════
	// VIDEO OPTIONS
	// ═══════════════════════════════════════════════════════════════
	const VIDEO_QUALITIES = [
		{ id: "best", label: "Best", format: "bestvideo" },
		{ id: "2160p", label: "4K", format: "bestvideo[height<=2160]/bestvideo" },
		{
			id: "1440p",
			label: "1440p",
			format: "bestvideo[height<=1440]/bestvideo",
		},
		{
			id: "1080p",
			label: "1080p",
			format: "bestvideo[height<=1080]/bestvideo",
		},
		{ id: "720p", label: "720p", format: "bestvideo[height<=720]/bestvideo" },
		{ id: "480p", label: "480p", format: "bestvideo[height<=480]/bestvideo" },
		{ id: "360p", label: "360p", format: "bestvideo[height<=360]/bestvideo" },
		{ id: "240p", label: "240p", format: "bestvideo[height<=240]/bestvideo" },
		{ id: "144p", label: "144p", format: "bestvideo[height<=144]/bestvideo" },
	];

	const VIDEO_CODECS = [
		{ id: "default", label: "Auto", sortArg: "" },
		{ id: "av1", label: "AV1", sortArg: "-S vcodec:av01" },
		{ id: "vp9", label: "VP9", sortArg: "-S vcodec:vp9" },
		{ id: "h264", label: "H.264", sortArg: "-S +vcodec:avc" },
	];

	// ═══════════════════════════════════════════════════════════════
	// AUDIO OPTIONS
	// ═══════════════════════════════════════════════════════════════
	const AUDIO_QUALITIES = [
		{ id: "best", label: "Best", format: "bestaudio" },
		{ id: "medium", label: "Medium", format: "bestaudio[abr<=128]/bestaudio" },
		{ id: "worst", label: "Smallest", format: "worstaudio" },
	];

	// Audio codec preference - matches audio codec to video codec for compatibility
	// Note: formatFilter uses single quotes to avoid breaking Python string literals
	const AUDIO_CODECS = [
		{ id: "auto", label: "Auto" },
		{ id: "mp3", label: "MP3", formatFilter: "[acodec='mp3']" },
		{ id: "aac", label: "AAC", formatFilter: "[acodec~='^mp4a']" },
		{ id: "opus", label: "Opus", formatFilter: "[acodec='opus']" },
	];

	// ═══════════════════════════════════════════════════════════════
	// SUBTITLE OPTIONS (Original first)
	// ═══════════════════════════════════════════════════════════════
	const SUBTITLE_FORMATS = [
		{ id: "original", label: "Original", convertArg: "" },
		{ id: "srt", label: "SRT", convertArg: "--convert-subs srt" },
		{ id: "vtt", label: "VTT", convertArg: "--convert-subs vtt" },
		{ id: "ass", label: "ASS", convertArg: "--convert-subs ass" },
	];

	// ═══════════════════════════════════════════════════════════════
	// STORAGE KEYS
	// ═══════════════════════════════════════════════════════════════
	const STORAGE_KEYS = {
		VIDEO_QUALITY: "ytdlp_video_quality",
		VIDEO_CODEC: "ytdlp_video_codec",
		VIDEO_OUTPUT: "ytdlp_video_output",
		AUDIO_QUALITY: "ytdlp_audio_quality",
		AUDIO_CODEC: "ytdlp_audio_codec",
		AUDIO_OUTPUT: "ytdlp_audio_output",
		SUBS_FORMAT: "ytdlp_subs_format",
		SUBS_OUTPUT: "ytdlp_subs_output",
		INCLUDE_VIDEO_ID: "ytdlp_include_video_id",
		PREFER_MP4: "ytdlp_prefer_mp4",
		DELETE_PY_AFTER_RUN: "ytdlp_delete_py_after_run",
		DELETE_COOKIE_AFTER_RUN: "ytdlp_delete_cookie_after_run",
		AUTO_EXPORT_COOKIES: "ytdlp_auto_export_cookies",
	};

	// ═══════════════════════════════════════════════════════════════
	// DEFAULTS
	// ═══════════════════════════════════════════════════════════════
	const DEFAULTS = {
		VIDEO_QUALITY: "best",
		VIDEO_CODEC: "default",
		VIDEO_OUTPUT: "merge",
		AUDIO_QUALITY: "best",
		AUDIO_CODEC: "auto",
		AUDIO_OUTPUT: "merge",
		SUBS_FORMAT: "original",
		SUBS_OUTPUT: "none",
		INCLUDE_VIDEO_ID: true,
		PREFER_MP4: false,
		DELETE_PY_AFTER_RUN: false,
		DELETE_COOKIE_AFTER_RUN: false,
		AUTO_EXPORT_COOKIES: false,
	};

	// ═══════════════════════════════════════════════════════════════
	// OVERWRITE EXISTING FILES
	// ═══════════════════════════════════════════════════════════════
	const FORCE_OVERWRITE = true;

	//================================================================================
	// STORAGE HELPERS
	//================================================================================

	function getStoredValue(key, defaultValue, validOptions = null) {
		try {
			const stored = GM_getValue(key, defaultValue);
			if (validOptions && !validOptions.some((v) => v.id === stored)) {
				return defaultValue;
			}
			return stored;
		} catch (_e) {
			return defaultValue;
		}
	}

	function setStoredValue(key, value) {
		try {
			GM_setValue(key, value);
		} catch (e) {
			console.warn("[yt-dlp] Failed to save setting:", e);
		}
	}

	// Getters
	const getVideoQuality = () =>
		getStoredValue(
			STORAGE_KEYS.VIDEO_QUALITY,
			DEFAULTS.VIDEO_QUALITY,
			VIDEO_QUALITIES,
		);
	const getVideoCodec = () =>
		getStoredValue(
			STORAGE_KEYS.VIDEO_CODEC,
			DEFAULTS.VIDEO_CODEC,
			VIDEO_CODECS,
		);
	const getVideoOutput = () =>
		getStoredValue(
			STORAGE_KEYS.VIDEO_OUTPUT,
			DEFAULTS.VIDEO_OUTPUT,
			OUTPUT_MODES,
		);
	const getAudioQuality = () =>
		getStoredValue(
			STORAGE_KEYS.AUDIO_QUALITY,
			DEFAULTS.AUDIO_QUALITY,
			AUDIO_QUALITIES,
		);
	const getAudioCodec = () =>
		getStoredValue(
			STORAGE_KEYS.AUDIO_CODEC,
			DEFAULTS.AUDIO_CODEC,
			AUDIO_CODECS,
		);
	const getAudioOutput = () =>
		getStoredValue(
			STORAGE_KEYS.AUDIO_OUTPUT,
			DEFAULTS.AUDIO_OUTPUT,
			OUTPUT_MODES,
		);
	const getSubsFormat = () =>
		getStoredValue(
			STORAGE_KEYS.SUBS_FORMAT,
			DEFAULTS.SUBS_FORMAT,
			SUBTITLE_FORMATS,
		);
	const getSubsOutput = () =>
		getStoredValue(
			STORAGE_KEYS.SUBS_OUTPUT,
			DEFAULTS.SUBS_OUTPUT,
			OUTPUT_MODES,
		);
	const getIncludeVideoId = () => {
		try {
			const stored = GM_getValue(
				STORAGE_KEYS.INCLUDE_VIDEO_ID,
				DEFAULTS.INCLUDE_VIDEO_ID,
			);
			return stored === true || stored === "true";
		} catch (_e) {
			return DEFAULTS.INCLUDE_VIDEO_ID;
		}
	};
	const getPreferMp4 = () => {
		try {
			const stored = GM_getValue(STORAGE_KEYS.PREFER_MP4, DEFAULTS.PREFER_MP4);
			return stored === true || stored === "true";
		} catch (_e) {
			return DEFAULTS.PREFER_MP4;
		}
	};
	const getDeletePyAfterRun = () => {
		try {
			const stored = GM_getValue(
				STORAGE_KEYS.DELETE_PY_AFTER_RUN,
				DEFAULTS.DELETE_PY_AFTER_RUN,
			);
			return stored === true || stored === "true";
		} catch (_e) {
			return DEFAULTS.DELETE_PY_AFTER_RUN;
		}
	};
	const getDeleteCookieAfterRun = () => {
		try {
			const stored = GM_getValue(
				STORAGE_KEYS.DELETE_COOKIE_AFTER_RUN,
				DEFAULTS.DELETE_COOKIE_AFTER_RUN,
			);
			return stored === true || stored === "true";
		} catch (_e) {
			return DEFAULTS.DELETE_COOKIE_AFTER_RUN;
		}
	};
	const getAutoExportCookies = () => {
		try {
			const stored = GM_getValue(
				STORAGE_KEYS.AUTO_EXPORT_COOKIES,
				DEFAULTS.AUTO_EXPORT_COOKIES,
			);
			return stored === true || stored === "true";
		} catch (_e) {
			return DEFAULTS.AUTO_EXPORT_COOKIES;
		}
	};

	// Setters
	const setVideoQuality = (v) => setStoredValue(STORAGE_KEYS.VIDEO_QUALITY, v);
	const setVideoCodec = (v) => setStoredValue(STORAGE_KEYS.VIDEO_CODEC, v);
	const setVideoOutput = (v) => setStoredValue(STORAGE_KEYS.VIDEO_OUTPUT, v);
	const setAudioQuality = (v) => setStoredValue(STORAGE_KEYS.AUDIO_QUALITY, v);
	const setAudioCodec = (v) => setStoredValue(STORAGE_KEYS.AUDIO_CODEC, v);
	const setAudioOutput = (v) => setStoredValue(STORAGE_KEYS.AUDIO_OUTPUT, v);
	const setSubsFormat = (v) => setStoredValue(STORAGE_KEYS.SUBS_FORMAT, v);
	const setSubsOutput = (v) => setStoredValue(STORAGE_KEYS.SUBS_OUTPUT, v);
	const setIncludeVideoId = (v) =>
		setStoredValue(STORAGE_KEYS.INCLUDE_VIDEO_ID, v);
	const setPreferMp4 = (v) => setStoredValue(STORAGE_KEYS.PREFER_MP4, v);
	const setDeletePyAfterRun = (v) =>
		setStoredValue(STORAGE_KEYS.DELETE_PY_AFTER_RUN, v);
	const setDeleteCookieAfterRun = (v) =>
		setStoredValue(STORAGE_KEYS.DELETE_COOKIE_AFTER_RUN, v);
	const setAutoExportCookies = (v) =>
		setStoredValue(STORAGE_KEYS.AUTO_EXPORT_COOKIES, v);

	// ═══════════════════════════════════════════════════════════════
	// COOKIE EXPORT (GM_cookie API → Netscape format)
	// ═══════════════════════════════════════════════════════════════

	/**
	 * Check whether the GM_cookie API is available.
	 * Supports three API styles:
	 *   - GM.cookie.list()    — promise-based (Tampermonkey 5.3+, Violentmonkey 2.35.1+)
	 *   - GM_cookie.list()    — object with methods (Tampermonkey 5.0+, Violentmonkey 2.35.1+)
	 *   - GM_cookie("list", …) — legacy function call (older Tampermonkey)
	 */
	function isCookieApiAvailable() {
		// Promise-based GM4 style: GM.cookie.list()
		if (
			typeof GM !== "undefined" &&
			GM.cookie &&
			typeof GM.cookie.list === "function"
		) {
			return "promise";
		}
		// Object with methods: GM_cookie.list() (both Tampermonkey and Violentmonkey)
		if (
			typeof GM_cookie === "object" &&
			GM_cookie !== null &&
			typeof GM_cookie.list === "function"
		) {
			return "object";
		}
		// Legacy function call: GM_cookie("list", …, callback)
		if (typeof GM_cookie === "function") {
			return "callback";
		}
		return false;
	}

	/**
	 * Fetch cookies for the given hostname via GM_cookie.
	 * Returns a Promise that resolves to an array of cookie objects.
	 */
	function fetchCookies(targetHostname) {
		const apiType = isCookieApiAvailable();

		if (apiType === "promise") {
			return GM.cookie
				.list({ url: `https://${targetHostname}/` })
				.catch(() => GM.cookie.list({ domain: targetHostname }))
				.catch(() => GM.cookie.list({}));
		}

		if (apiType === "object") {
			// GM_cookie.list(details) — may use callback or return promise depending on manager
			return new Promise((resolve, reject) => {
				try {
					const result = GM_cookie.list(
						{ url: `https://${targetHostname}/` },
						(cookies, error) => {
							if (error) {
								GM_cookie.list(
									{ domain: targetHostname },
									(cookies2, error2) => {
										if (error2) reject(new Error(error2));
										else resolve(cookies2 || []);
									},
								);
							} else {
								resolve(cookies || []);
							}
						},
					);
					// If it returned a Promise (Violentmonkey), use that instead
					if (result && typeof result.then === "function") {
						result.then(resolve).catch(() =>
							GM_cookie.list({ domain: targetHostname })
								.then(resolve)
								.catch(() => GM_cookie.list({}).then(resolve).catch(reject)),
						);
					}
				} catch (e) {
					reject(e);
				}
			});
		}

		if (apiType === "callback") {
			return new Promise((resolve, reject) => {
				GM_cookie(
					"list",
					{ url: `https://${targetHostname}/` },
					(cookies, error) => {
						if (error) {
							GM_cookie(
								"list",
								{ domain: targetHostname },
								(cookies2, error2) => {
									if (error2) reject(new Error(error2));
									else resolve(cookies2 || []);
								},
							);
						} else {
							resolve(cookies || []);
						}
					},
				);
			});
		}

		return Promise.reject(new Error("GM_cookie API not available"));
	}

	/**
	 * Convert an array of cookie objects to Netscape cookie-file format.
	 */
	function toNetscapeFormat(cookies) {
		const header = [
			"# Netscape HTTP Cookie File",
			"# https://curl.haxx.se/docs/http-cookies.html",
			"# This file was generated by yt-dlp Python-Downloader",
			"",
		].join("\n");

		const lines = cookies.map((c) => {
			const domain = c.domain || "";
			// TRUE if domain starts with . (matches subdomains)
			const flag = domain.startsWith(".") ? "TRUE" : "FALSE";
			const path = c.path || "/";
			const secure = c.secure ? "TRUE" : "FALSE";
			// Session cookies (no expiration) get 0
			const expiration = c.expirationDate ? Math.floor(c.expirationDate) : 0;
			const name = c.name || "";
			const value = c.value || "";
			return `${domain}\t${flag}\t${path}\t${secure}\t${expiration}\t${name}\t${value}`;
		});

		// biome-ignore lint/style/useTemplate: readability - header is distinct from lines content
		return header + lines.join("\n") + "\n";
	}

	/**
	 * Export cookies for the current domain as a Netscape-format .txt file.
	 * @param {string} [targetHostname] - Override hostname (defaults to current page)
	 * @param {boolean} [silent] - If true, suppress success notification (for auto-export)
	 * @returns {Promise<boolean>} - true if export succeeded
	 */
	/**
	 * Show a large centered banner explaining that the GM_cookie API is not available,
	 * with instructions on how to enable it. User must click to dismiss.
	 */
	function showCookieApiBanner() {
		// Remove any existing banner first
		const existing = document.getElementById("ytdlp-cookie-banner-host");
		if (existing) existing.remove();

		// Create a separate shadow host for the banner so it sits above everything
		const bannerHost = document.createElement("div");
		bannerHost.id = "ytdlp-cookie-banner-host";
		Object.assign(bannerHost.style, {
			position: "fixed",
			top: "0",
			left: "0",
			width: "100vw",
			height: "100vh",
			zIndex: "2147483647",
			pointerEvents: "auto",
		});

		const bannerShadow = bannerHost.attachShadow({ mode: "closed" });

		const style = document.createElement("style");
		style.textContent = `
			:host { all: initial; }
			* { box-sizing: border-box; }

			.ytdlp-banner-overlay {
				position: fixed;
				top: 0; left: 0; right: 0; bottom: 0;
				background: rgba(0, 0, 0, 0.7);
				display: flex;
				align-items: center;
				justify-content: center;
				z-index: 2147483647;
				font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
				padding: 20px;
			}

			.ytdlp-banner {
				background: #1e1e1e;
				border: 1px solid #444;
				border-radius: 12px;
				box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6);
				max-width: 560px;
				width: 100%;
				padding: 28px 32px;
				color: #e0e0e0;
				animation: ytdlp-banner-in 0.25s ease-out;
			}

			@keyframes ytdlp-banner-in {
				from { opacity: 0; transform: scale(0.95) translateY(10px); }
				to   { opacity: 1; transform: scale(1) translateY(0); }
			}

			.banner-icon { font-size: 36px; text-align: center; margin-bottom: 12px; }
			.banner-title { font-size: 18px; font-weight: 700; text-align: center; margin-bottom: 16px; color: #f44336; }
			.banner-desc { font-size: 13px; line-height: 1.65; color: #ccc; margin-bottom: 16px; }
			.banner-desc strong { color: #fff; }

			.banner-section {
				background: #2a2a2a;
				border: 1px solid #3a3a3a;
				border-radius: 8px;
				padding: 14px 16px;
				margin: 12px 0;
			}
			.banner-section-title { font-size: 13px; font-weight: 600; color: #4CAF50; margin-bottom: 8px; }
			.banner-steps { margin: 0; padding-left: 20px; font-size: 12.5px; line-height: 1.7; color: #ccc; }
			.banner-steps li { margin-bottom: 4px; }
			.banner-steps strong { color: #fff; }

			.banner-divider { border: none; border-top: 1px solid #3a3a3a; margin: 16px 0; }

			.banner-alt { font-size: 12px; color: #999; text-align: center; margin-bottom: 16px; }
			.banner-alt strong { color: #ccc; }
			.banner-alt a { color: #64B5F6; text-decoration: underline; cursor: pointer; }

			.banner-dismiss {
				display: block;
				width: 100%;
				padding: 12px;
				background: #f44336;
				color: #fff;
				border: none;
				border-radius: 6px;
				font-size: 14px;
				font-weight: 600;
				cursor: pointer;
				transition: background 0.15s;
				text-align: center;
			}
			.banner-dismiss:hover { background: #d32f2f; }
		`;
		bannerShadow.appendChild(style);

		// Build everything with pure DOM (no innerHTML)
		const overlay = document.createElement("div");
		overlay.className = "ytdlp-banner-overlay";

		const banner = document.createElement("div");
		banner.className = "ytdlp-banner";

		// Icon
		const icon = document.createElement("div");
		icon.className = "banner-icon";
		icon.textContent = "\u{1F36A}"; // 🍪
		banner.appendChild(icon);

		// Title
		const title = document.createElement("div");
		title.className = "banner-title";
		title.textContent = "Cookie API Not Available";
		banner.appendChild(title);

		// Description
		const desc = document.createElement("div");
		desc.className = "banner-desc";
		const descP = document.createElement("p");
		descP.append(
			"Your userscript manager does not expose the ",
			Object.assign(document.createElement("strong"), {
				textContent: "GM_cookie",
			}),
			" API, which is required to export browser cookies for yt-dlp.",
		);
		desc.appendChild(descP);
		banner.appendChild(desc);

		// Helper to build a setup section
		const buildSection = (titleText, steps) => {
			const section = document.createElement("div");
			section.className = "banner-section";

			const sTitle = document.createElement("div");
			sTitle.className = "banner-section-title";
			sTitle.textContent = titleText;
			section.appendChild(sTitle);

			const ol = document.createElement("ol");
			ol.className = "banner-steps";
			steps.forEach((stepParts) => {
				const li = document.createElement("li");
				stepParts.forEach((part) => {
					if (typeof part === "string") {
						li.appendChild(document.createTextNode(part));
					} else {
						const strong = document.createElement("strong");
						strong.textContent = part.bold;
						li.appendChild(strong);
					}
				});
				ol.appendChild(li);
			});
			section.appendChild(ol);
			return section;
		};

		// Violentmonkey section
		banner.appendChild(
			buildSection("Violentmonkey (recommended, Beta v2.35.1+)", [
				[
					"Go to ",
					{
						bold: "Violentmonkey \u2192 Settings \u2192 Advanced \u2192 Script settings",
					},
				],
				[
					"Enable ",
					{ bold: "\u201CAllow GM_cookie to access HTTP-only cookies\u201D" },
				],
				[
					"Then in the ",
					{ bold: "yt-dlp Python-Downloader script \u2192 Settings tab" },
					", check the box for ",
					{ bold: "\u201CAllow GM_cookie to access HTTP-only cookies\u201D" },
				],
			]),
		);

		// Tampermonkey section
		banner.appendChild(
			buildSection("Tampermonkey", [
				["Go to ", { bold: "Tampermonkey \u2192 Settings" }],
				["Set ", { bold: "Config mode" }, " to ", { bold: "Advanced" }],
				[
					"Under ",
					{ bold: "Security" },
					", set ",
					{ bold: "\u201CAllow scripts to access cookies\u201D" },
					" to ",
					{ bold: "All" },
				],
			]),
		);

		// Divider
		const divider = document.createElement("hr");
		divider.className = "banner-divider";
		banner.appendChild(divider);

		// Alternative
		const alt = document.createElement("div");
		alt.className = "banner-alt";
		const altStrong = document.createElement("strong");
		altStrong.textContent = "Alternative: ";
		alt.appendChild(altStrong);
		alt.appendChild(
			document.createTextNode("Use a dedicated cookie extension like "),
		);
		const altLink = document.createElement("a");
		altLink.href =
			"https://chromewebstore.google.com/detail/get-cookiestxt-locally/cclelndahbckbenkjhflpdbgdldlbecc";
		altLink.target = "_blank";
		altLink.rel = "noopener noreferrer";
		altLink.textContent = "\u201CGet cookies.txt LOCALLY\u201D";
		alt.appendChild(altLink);
		alt.appendChild(
			document.createTextNode(
				" and place the exported file next to the .py script.",
			),
		);
		banner.appendChild(alt);

		// Dismiss button
		const dismissBtn = document.createElement("button");
		dismissBtn.className = "banner-dismiss";
		dismissBtn.textContent = "Got it";
		dismissBtn.addEventListener("click", (e) => {
			e.preventDefault();
			e.stopPropagation();
			bannerHost.remove();
		});
		banner.appendChild(dismissBtn);

		// Dismiss on overlay click (outside banner)
		overlay.addEventListener("mousedown", (e) => {
			if (e.target === overlay) {
				e.preventDefault();
				e.stopPropagation();
				bannerHost.remove();
			}
		});

		// Dismiss on Escape key
		const escHandler = (e) => {
			if (e.key === "Escape") {
				bannerHost.remove();
				document.removeEventListener("keydown", escHandler, true);
			}
		};
		document.addEventListener("keydown", escHandler, true);

		overlay.appendChild(banner);
		bannerShadow.appendChild(overlay);
		document.body.appendChild(bannerHost);
	}

	async function exportCookies(targetHostname, silent = false) {
		const host = targetHostname || window.location.hostname;
		const cookieFilename = `${host}_cookies.txt`;

		const apiType = isCookieApiAvailable();
		if (!apiType) {
			if (!silent) {
				showCookieApiBanner();
			}
			return false;
		}

		try {
			const cookies = await fetchCookies(host);

			if (!cookies || cookies.length === 0) {
				showNotification(`No cookies found for ${host}`, "warning");
				return false;
			}

			const content = toNetscapeFormat(cookies);

			// Trigger file download
			const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
			const blobUrl = URL.createObjectURL(blob);
			const a = Object.assign(document.createElement("a"), {
				href: blobUrl,
				download: cookieFilename,
			});
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(blobUrl);

			if (!silent) {
				showNotification(`🍪 Exported ${cookies.length} cookies`, "success");
			}
			return true;
		} catch (e) {
			console.error("[yt-dlp] Cookie export failed:", e);
			showNotification(`Cookie export failed: ${e.message || e}`, "error");
			return false;
		}
	}

	// Helpers
	const findOption = (options, id) => options.find((o) => o.id === id);
	const getLabel = (options, id) =>
		findOption(options, id)?.label || options[0].label;
	const isYouTubeDomain = () =>
		[
			"www.youtube.com",
			"youtube.com",
			"m.youtube.com",
			"music.youtube.com",
		].includes(window.location.hostname);

	//================================================================================
	// VALIDATION & STATE HELPERS
	//================================================================================

	function getComponentStates() {
		const videoOut = getVideoOutput();
		const audioOut = getAudioOutput();
		const subsOut = getSubsOutput();

		const hasVideo = isEnabled(videoOut);
		const hasAudio = isEnabled(audioOut);
		const hasSubs = isEnabled(subsOut);

		const activeCount = [hasVideo, hasAudio, hasSubs].filter(Boolean).length;

		return { activeCount };
	}

	// Count how many components have merge flag
	function getMergeCount() {
		const videoOut = getVideoOutput();
		const audioOut = getAudioOutput();
		const subsOut = getSubsOutput();
		return [
			hasMergeFlag(videoOut),
			hasMergeFlag(audioOut),
			hasMergeFlag(subsOut),
		].filter(Boolean).length;
	}

	// Set ALL components to merge (preserving separate flags)
	function setAllToMerge() {
		const videoOut = getVideoOutput();
		const audioOut = getAudioOutput();
		const subsOut = getSubsOutput();

		setVideoOutput(hasSeparateFlag(videoOut) ? "merge-separate" : "merge");
		setAudioOutput(hasSeparateFlag(audioOut) ? "merge-separate" : "merge");
		setSubsOutput(hasSeparateFlag(subsOut) ? "merge-separate" : "merge");
	}

	// If only one component has merge, remove it (can't merge alone)
	function cleanupLoneMerge() {
		if (getMergeCount() === 1) {
			const videoOut = getVideoOutput();
			const audioOut = getAudioOutput();
			const subsOut = getSubsOutput();

			if (hasMergeFlag(videoOut)) {
				setVideoOutput(hasSeparateFlag(videoOut) ? "separate" : "none");
			}
			if (hasMergeFlag(audioOut)) {
				setAudioOutput(hasSeparateFlag(audioOut) ? "separate" : "none");
			}
			if (hasMergeFlag(subsOut)) {
				setSubsOutput(hasSeparateFlag(subsOut) ? "separate" : "none");
			}
		}
	}

	// Toggle merge for a component
	function toggleMerge(currentOutput, setter) {
		const hadMerge = hasMergeFlag(currentOutput);

		if (hadMerge) {
			// Clicking merge OFF: remove merge from THIS component only
			setter(hasSeparateFlag(currentOutput) ? "separate" : "none");
			// If only 1 merge remains after this, remove it too (can't merge alone)
			cleanupLoneMerge();
		} else {
			// Clicking merge ON: set ALL components to merge
			// User can deselect the ones they don't want
			setAllToMerge();
		}
	}

	// Toggle separate for a component
	function toggleSeparate(currentOutput, setter) {
		const hadMerge = hasMergeFlag(currentOutput);
		const hadSeparate = hasSeparateFlag(currentOutput);

		if (hadSeparate) {
			// Remove separate
			setter(hadMerge ? "merge" : "none");
		} else {
			// Add separate
			if (currentOutput === "none") {
				setter("separate");
			} else {
				setter("merge-separate");
			}
		}
		// No need to cleanup here - separate doesn't affect merge count
	}

	// Set component to None
	function setToNone(setter) {
		setter("none");
		// After setting to none, check if only 1 merge left
		cleanupLoneMerge();
	}

	function validateSettings() {
		const state = getComponentStates();

		// Rule 1: At least one component must be non-None
		if (state.activeCount === 0) {
			return { valid: false };
		}

		return { valid: true };
	}

	//================================================================================
	// TOOLTIP REPOSITIONING (shared across buttons)
	//================================================================================

	function repositionTooltip(btnEl) {
		if (!btnEl.hasAttribute("data-tooltip")) return;
		const rect = btnEl.getBoundingClientRect();
		const tooltipText = btnEl.getAttribute("data-tooltip") || "";
		const temp = document.createElement("div");
		temp.style.cssText =
			"position:fixed;top:-9999px;left:-9999px;white-space:pre-line;" +
			"font-size:10px;padding:4px 8px;background:rgba(0,0,0,0.9);" +
			"color:#fff;border-radius:4px;z-index:9999;max-width:300px;" +
			"pointer-events:none;font-family:sans-serif";
		temp.textContent = tooltipText;
		document.body.appendChild(temp);
		const wouldOverflow =
			rect.right + temp.offsetWidth > window.innerWidth - 10;
		document.body.removeChild(temp);
		btnEl.classList.toggle("ytdlp-tooltip-right", wouldOverflow);
	}

	//================================================================================
	// CONTEXT MENU
	//================================================================================

	const ContextMenu = {
		shadowHost: null,
		shadowRoot: null,
		element: null,
		isOpen: false,
		closeHandler: null,
		updateFunctions: [], // Store update functions for dynamic state

		getStyles() {
			return `
                :host { all: initial; }
                * { box-sizing: border-box; }

                .ytdlp-context-menu {
                    position: fixed;
                    background: #2d2d2d;
                    border: 1px solid #444;
                    border-radius: 8px;
                    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.5);
                    padding: 8px;
                    z-index: 2147483647;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                    font-size: 13px;
                    color: #e0e0e0;
                    user-select: none;
                    pointer-events: auto;
                    display: none;
                    width: fit-content;
                }

                .ytdlp-context-menu.visible { display: block; }

                /* Component rows (Video, Audio, Subtitle) */
                .ytdlp-component-row {
                    padding: 8px 12px;
                    border-radius: 4px;
                    position: relative;
                    transition: background 0.15s;
                }

                .ytdlp-component-row:not(:last-child) {
                    border-bottom: 1px solid #3a3a3a;
                }

                .ytdlp-component-row:hover {
                    background: #3a3a3a;
                }



                .ytdlp-component-header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    margin-bottom: 6px;
                }

                .ytdlp-component-title {
                    font-size: 11px;
                    font-weight: 600;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    color: #aaa;
                }

                .ytdlp-component-arrow {
                    font-size: 9px;
                    opacity: 0.5;
                    transition: opacity 0.15s;
                }

                .ytdlp-component-row:hover .ytdlp-component-arrow {
                    opacity: 1;
                }

                /* Output mode buttons */
                .ytdlp-output-modes {
                    display: flex;
                    gap: 4px;
                }

                .ytdlp-output-btn {
                    padding: 4px 8px;
                    font-size: 11px;
                    border-radius: 4px;
                    cursor: pointer;
                    background: #3a3a3a;
                    color: #999;
                    transition: all 0.15s;
                    border: 1px solid transparent;
                }

                .ytdlp-output-btn:hover:not(.disabled):not(.selected) {
                    background: #444;
                    color: #ccc;
                }

                .ytdlp-output-btn.selected {
                    background: #4a6da7;
                    color: #fff;
                    border-color: #5a7db7;
                }

                .ytdlp-output-btn.selected:hover {
                    background: #5a7db7;
                    border-color: #6a8dc7;
                }

                .ytdlp-output-btn.disabled {
                    opacity: 0.35;
                    cursor: not-allowed;
                    pointer-events: none;
                }

                .ytdlp-output-btn[data-tooltip] {
                    position: relative;
                }

                .ytdlp-output-btn[data-tooltip]:hover::before {
                    content: attr(data-tooltip);
                    position: absolute;
                    bottom: calc(100% + 6px);
                    left: 50%;
                    transform: translateX(-50%);
                    background: rgba(0, 0, 0, 0.9);
                    color: #fff;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 10px;
                    white-space: pre-line;
                    z-index: 100;
                    pointer-events: none;
                }

                /* Detail submenu */
                .ytdlp-detail-submenu {
                    display: none;
                    position: absolute;
                    right: calc(100% + 4px);
                    top: 0;
                    background: #2d2d2d;
                    border: 1px solid #444;
                    border-radius: 8px;
                    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.5);
                    padding: 8px;
                    min-width: 140px;
                }

                /* Invisible bridge to prevent hover loss when moving to submenu */
                .ytdlp-detail-submenu::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    bottom: 0;
                    right: -8px;
                    width: 12px;
                }

                .ytdlp-component-row.submenu-open .ytdlp-detail-submenu {
                    display: block;
                }

                .ytdlp-detail-section {
                    padding: 4px 0;
                }

                .ytdlp-detail-section:not(:last-child) {
                    border-bottom: 1px solid #3a3a3a;
                    margin-bottom: 4px;
                    padding-bottom: 8px;
                }

                .ytdlp-detail-header {
                    padding: 4px 10px;
                    font-size: 10px;
                    text-transform: uppercase;
                    color: #888;
                    letter-spacing: 0.5px;
                }

                .ytdlp-detail-item {
                    padding: 6px 10px;
                    font-size: 12px;
                    cursor: pointer;
                    border-radius: 4px;
                    transition: background 0.15s;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }

                .ytdlp-detail-item:hover {
                    background: #3a3a3a;
                }

                .ytdlp-detail-item.selected::before {
                    content: '✓';
                    font-size: 10px;
                    color: #4CAF50;
                    width: 12px;
                }

                .ytdlp-detail-item:not(.selected)::before {
                    content: '';
                    width: 12px;
                    display: inline-block;
                }

                /* Simple menu row (Comments) */
                .ytdlp-menu-row {
                    display: flex;
                    align-items: center;
                    padding: 10px 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    transition: background 0.15s;
                }

                .ytdlp-menu-row:hover {
                    background: #3a3a3a;
                }

                .ytdlp-menu-row:not(:last-child) {
                    border-bottom: 1px solid #3a3a3a;
                }

                /* Download button */
                .ytdlp-download-btn {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 10px 12px;
                    margin-top: 4px;
                    background: #4CAF50;
                    color: #fff;
                    font-weight: 500;
                    font-size: 13px;
                    border-radius: 4px;
                    cursor: pointer;
                    transition: background 0.15s;
                }

                .ytdlp-download-btn:hover:not(.disabled) {
                    background: #43a047;
                }

                .ytdlp-download-btn.disabled {
                    background: #555;
                    cursor: not-allowed;
                    opacity: 0.6;
                }

                /* Support button */
                .ytdlp-support-btn {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 8px 12px;
                    margin-top: 6px;
                    background: transparent;
                    border: 1px solid #444;
                    color: #888;
                    font-size: 12px;
                    border-radius: 4px;
                    cursor: pointer;
                    transition: all 0.15s;
                    text-decoration: none;
                }

                .ytdlp-support-btn:hover {
                    background: #3a3a3a;
                    border-color: #4CAF50;
                    color: #4CAF50;
                }

                .ytdlp-support-btn[data-tooltip] {
                    position: relative;
                }

                .ytdlp-support-btn[data-tooltip]:hover::before {
                    content: attr(data-tooltip);
                    position: absolute;
                    bottom: calc(100% + 6px);
                    left: 50%;
                    transform: translateX(-50%);
                    background: rgba(0, 0, 0, 0.9);
                    color: #fff;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 10px;
                    white-space: pre-line;
                    z-index: 100;
                    pointer-events: none;
                }

                .ytdlp-output-btn.ytdlp-tooltip-right[data-tooltip]:hover::before,
                .ytdlp-support-btn.ytdlp-tooltip-right[data-tooltip]:hover::before {
                    left: auto;
                    right: 0;
                    transform: none;
                }

                /* Toggle item (reused in Options flyout) */
                .ytdlp-toggle-item {
                    padding: 6px 10px;
                    font-size: 12px;
                    cursor: pointer;
                    border-radius: 4px;
                    transition: background 0.15s;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    white-space: nowrap;
                }

                .ytdlp-toggle-item:hover {
                    background: #3a3a3a;
                }

                .ytdlp-toggle-item .check {
                    width: 12px;
                    font-size: 10px;
                    color: #4CAF50;
                }
            `;
		},

		init() {
			if (this.shadowHost) return;

			try {
				this.shadowHost = document.createElement("div");
				this.shadowHost.id = "ytdlp-context-menu-host";
				Object.assign(this.shadowHost.style, {
					position: "fixed",
					top: "0",
					left: "0",
					width: "0",
					height: "0",
					overflow: "visible",
					zIndex: "2147483647",
					pointerEvents: "none",
				});

				this.shadowRoot = this.shadowHost.attachShadow({ mode: "open" });

				const style = document.createElement("style");
				style.textContent = this.getStyles();
				this.shadowRoot.appendChild(style);

				this.element = document.createElement("div");
				this.element.className = "ytdlp-context-menu";
				this.shadowRoot.appendChild(this.element);

				document.body.appendChild(this.shadowHost);

				document.addEventListener(
					"keydown",
					(e) => {
						if (e.key === "Escape" && this.isOpen) this.hide();
					},
					true,
				);
			} catch (e) {
				console.error("[yt-dlp] Failed to init context menu:", e);
			}
		},

		show(x, y, onDownload) {
			if (!this.shadowHost) this.init();
			if (!this.element) return;

			this.isOpen = true;
			this.element.textContent = "";
			this.updateFunctions = [];

			const showCodecOption = isYouTubeDomain();
			let downloadBtn = null;

			// Master update function - updates all dynamic states
			const updateAllStates = () => {
				this.updateFunctions.forEach((fn) => {
					try {
						fn();
					} catch (e) {
						console.warn("[yt-dlp] Update error:", e);
					}
				});
				updateDownloadState();
			};

			// Helper to update download button state
			const updateDownloadState = () => {
				if (downloadBtn) {
					const valid = validateSettings().valid;
					downloadBtn.classList.toggle("disabled", !valid);
				}
			};

			// Helper to build a component row (Video, Audio, Subtitle)
			const buildComponentRow = (
				title,
				outputGetter,
				outputSetter,
				detailBuilder,
			) => {
				const row = document.createElement("div");
				row.className = "ytdlp-component-row";

				// Header with title and arrow
				const header = document.createElement("div");
				header.className = "ytdlp-component-header";

				const titleEl = document.createElement("span");
				titleEl.className = "ytdlp-component-title";
				titleEl.textContent = title;
				header.appendChild(titleEl);

				const arrow = document.createElement("span");
				arrow.className = "ytdlp-component-arrow";
				arrow.textContent = "◀";
				header.appendChild(arrow);

				row.appendChild(header);

				// Output mode buttons: [Merge] [Sep] [None]
				const modesContainer = document.createElement("div");
				modesContainer.className = "ytdlp-output-modes";

				const mergeBtn = document.createElement("div");
				mergeBtn.className = "ytdlp-output-btn";
				mergeBtn.textContent = "Merge";
				mergeBtn.setAttribute(
					"data-tooltip",
					"Include in merged file (syncs with other components)",
				);

				const sepBtn = document.createElement("div");
				sepBtn.className = "ytdlp-output-btn";
				sepBtn.textContent = "Sep";
				sepBtn.setAttribute("data-tooltip", "Keep as standalone file");

				const noneBtn = document.createElement("div");
				noneBtn.className = "ytdlp-output-btn";
				noneBtn.textContent = "None";
				noneBtn.setAttribute("data-tooltip", "Do not download this component");

				mergeBtn.onclick = (e) => {
					e.preventDefault();
					e.stopPropagation();
					toggleMerge(outputGetter(), outputSetter);
					updateAllStates();
				};

				sepBtn.onclick = (e) => {
					e.preventDefault();
					e.stopPropagation();
					toggleSeparate(outputGetter(), outputSetter);
					updateAllStates();
				};

				noneBtn.onclick = (e) => {
					e.preventDefault();
					e.stopPropagation();
					setToNone(outputSetter);
					updateAllStates();
				};

				modesContainer.appendChild(mergeBtn);
				modesContainer.appendChild(sepBtn);
				modesContainer.appendChild(noneBtn);
				row.appendChild(modesContainer);

				// Detail submenu
				const submenu = document.createElement("div");
				submenu.className = "ytdlp-detail-submenu";
				detailBuilder(submenu);
				row.appendChild(submenu);

				// Update function for this row
				const updateRowState = () => {
					const currentOutput = outputGetter();
					const isMerge = hasMergeFlag(currentOutput);
					const isSeparate = hasSeparateFlag(currentOutput);
					const isNone = currentOutput === "none";

					// Update button states - Merge and Sep can both be selected
					// Merge is ALWAYS clickable (clicking sets all to merge)
					mergeBtn.classList.toggle("selected", isMerge);
					sepBtn.classList.toggle("selected", isSeparate);
					noneBtn.classList.toggle("selected", isNone);
				};

				// Register update function
				this.updateFunctions.push(updateRowState);
				updateRowState();

				// Hover to open submenu (always available)
				row.addEventListener("mouseenter", () => {
					// Close all other submenus first
					this.element
						.querySelectorAll(".ytdlp-component-row.submenu-open")
						.forEach((r) => {
							if (r !== row) r.classList.remove("submenu-open");
						});
					row.classList.add("submenu-open");
					requestAnimationFrame(() => {
						try {
							const rowRect = row.getBoundingClientRect();
							const submenuRect = submenu.getBoundingClientRect();
							submenu.style.top = "0";
							submenu.style.bottom = "";
							if (rowRect.top + submenuRect.height > window.innerHeight - 10) {
								submenu.style.top = "auto";
								submenu.style.bottom = "0";
							}
						} catch (_e) {
							/* ignore */
						}
					});
				});

				row.addEventListener("mouseleave", () => {
					row.classList.remove("submenu-open");
				});

				return row;
			};

			// Helper to build detail items
			const buildDetailSection = (
				container,
				headerText,
				options,
				currentValueGetter,
				onSelect,
			) => {
				const section = document.createElement("div");
				section.className = "ytdlp-detail-section";

				const header = document.createElement("div");
				header.className = "ytdlp-detail-header";
				header.textContent = headerText;
				section.appendChild(header);

				const items = [];

				options.forEach((opt) => {
					const item = document.createElement("div");
					item.className = "ytdlp-detail-item";
					item.textContent = opt.label;

					item.onclick = (e) => {
						e.preventDefault();
						e.stopPropagation();
						items.forEach((el) => {
							el.classList.remove("selected");
						});
						item.classList.add("selected");
						onSelect(opt.id);
					};

					items.push(item);
					section.appendChild(item);
				});

				// Update selection state
				const updateSelection = () => {
					const currentValue = currentValueGetter();
					items.forEach((item, index) => {
						item.classList.toggle(
							"selected",
							options[index].id === currentValue,
						);
					});
				};

				updateSelection();
				container.appendChild(section);
			};

			// ─────────────────────────────────────────────────────────────
			// VIDEO ROW
			// ─────────────────────────────────────────────────────────────
			const videoRow = buildComponentRow(
				"VIDEO",
				getVideoOutput,
				setVideoOutput,
				(submenu) => {
					buildDetailSection(
						submenu,
						"Quality",
						VIDEO_QUALITIES,
						getVideoQuality,
						setVideoQuality,
					);
					if (showCodecOption) {
						buildDetailSection(
							submenu,
							"Codec",
							VIDEO_CODECS,
							getVideoCodec,
							setVideoCodec,
						);
					}
				},
			);
			this.element.appendChild(videoRow);

			// ─────────────────────────────────────────────────────────────
			// AUDIO ROW
			// ─────────────────────────────────────────────────────────────
			const audioRow = buildComponentRow(
				"AUDIO",
				getAudioOutput,
				setAudioOutput,
				(submenu) => {
					buildDetailSection(
						submenu,
						"Quality",
						AUDIO_QUALITIES,
						getAudioQuality,
						setAudioQuality,
					);
					// Audio format selection available on all sites (SoundCloud, etc.)
					buildDetailSection(
						submenu,
						"Format",
						AUDIO_CODECS,
						getAudioCodec,
						setAudioCodec,
					);
				},
			);
			this.element.appendChild(audioRow);

			// ─────────────────────────────────────────────────────────────
			// SUBTITLE ROW
			// ─────────────────────────────────────────────────────────────
			const subtitleRow = buildComponentRow(
				"SUBTITLE",
				getSubsOutput,
				setSubsOutput,
				(submenu) => {
					buildDetailSection(
						submenu,
						"Format",
						SUBTITLE_FORMATS,
						getSubsFormat,
						setSubsFormat,
					);
				},
			);
			this.element.appendChild(subtitleRow);

			// ─────────────────────────────────────────────────────────────
			// COMMENTS ROW
			// ─────────────────────────────────────────────────────────────
			const commentsRow = document.createElement("div");
			commentsRow.className = "ytdlp-menu-row";
			commentsRow.textContent = "💬 Comments Only";
			commentsRow.onclick = (e) => {
				e.preventDefault();
				e.stopPropagation();
				onDownload("comments");
			};
			this.element.appendChild(commentsRow);

			// ─────────────────────────────────────────────────────────────
			// THUMBNAILS ROW
			// ─────────────────────────────────────────────────────────────
			const thumbnailsRow = document.createElement("div");
			thumbnailsRow.className = "ytdlp-menu-row";
			thumbnailsRow.textContent = "🖼️ Thumbnail";
			thumbnailsRow.onclick = (e) => {
				e.preventDefault();
				e.stopPropagation();
				onDownload("thumbnails");
			};
			this.element.appendChild(thumbnailsRow);

			// ─────────────────────────────────────────────────────────────
			// EXPORT COOKIES ROW
			// ─────────────────────────────────────────────────────────────
			const cookiesRow = document.createElement("div");
			cookiesRow.className = "ytdlp-menu-row";
			cookiesRow.textContent = "🍪 Export Cookies";
			cookiesRow.onclick = (e) => {
				e.preventDefault();
				e.stopPropagation();
				exportCookies();
			};
			this.element.appendChild(cookiesRow);

			// ─────────────────────────────────────────────────────────────
			// FORMATS ROW
			// ─────────────────────────────────────────────────────────────
			const formatsRow = document.createElement("div");
			formatsRow.className = "ytdlp-menu-row";
			formatsRow.textContent = "📋 List Formats";
			formatsRow.onclick = (e) => {
				e.preventDefault();
				e.stopPropagation();
				onDownload("formats");
			};
			this.element.appendChild(formatsRow);

			// ─────────────────────────────────────────────────────────────
			// OPTIONS ROW (flyout submenu, same mechanics as V/A/S rows)
			// ─────────────────────────────────────────────────────────────
			const optionsRow = document.createElement("div");
			optionsRow.className = "ytdlp-component-row";

			const optionsHeader = document.createElement("div");
			optionsHeader.className = "ytdlp-component-header";

			const optionsTitle = document.createElement("span");
			optionsTitle.className = "ytdlp-component-title";
			optionsTitle.textContent = "\u2699\uFE0F OPTIONS";
			optionsHeader.appendChild(optionsTitle);

			const optionsArrow = document.createElement("span");
			optionsArrow.className = "ytdlp-component-arrow";
			optionsArrow.textContent = "◀";
			optionsHeader.appendChild(optionsArrow);

			optionsRow.appendChild(optionsHeader);

			// Flyout submenu
			const optionsSubmenu = document.createElement("div");
			optionsSubmenu.className = "ytdlp-detail-submenu";

			// Helper to build a toggle item (checkbox-style)
			const buildToggleItem = (label, getter, setter, onChange) => {
				const item = document.createElement("div");
				item.className = "ytdlp-toggle-item";

				const check = document.createElement("span");
				check.className = "check";
				check.textContent = getter() ? "✓" : "";

				const text = document.createElement("span");
				text.textContent = label;

				item.appendChild(check);
				item.appendChild(text);

				item.addEventListener("click", (e) => {
					e.preventDefault();
					e.stopPropagation();
					const newValue = !getter();
					setter(newValue);
					check.textContent = newValue ? "✓" : "";
					if (onChange) onChange(newValue);
				});

				return { element: item, check };
			};

			const optionsSection = document.createElement("div");
			optionsSection.className = "ytdlp-detail-section";

			const { element: videoIdEl } = buildToggleItem(
				"Include Video ID",
				getIncludeVideoId,
				setIncludeVideoId,
				() => {
					if (window._ytdlpUpdateTooltip) window._ytdlpUpdateTooltip();
				},
			);
			optionsSection.appendChild(videoIdEl);

			const { element: mp4El } = buildToggleItem(
				"Prefer MP4",
				getPreferMp4,
				setPreferMp4,
				() => {
					if (window._ytdlpUpdateTooltip) window._ytdlpUpdateTooltip();
				},
			);
			optionsSection.appendChild(mp4El);

			const { element: deletePyEl } = buildToggleItem(
				"Delete .py After Run",
				getDeletePyAfterRun,
				setDeletePyAfterRun,
			);
			optionsSection.appendChild(deletePyEl);

			const { element: deleteCookieEl } = buildToggleItem(
				"Delete Cookie After Run",
				getDeleteCookieAfterRun,
				setDeleteCookieAfterRun,
			);
			optionsSection.appendChild(deleteCookieEl);

			const { element: autoExportEl } = buildToggleItem(
				"Auto Export Cookies",
				getAutoExportCookies,
				setAutoExportCookies,
			);
			optionsSection.appendChild(autoExportEl);

			optionsSubmenu.appendChild(optionsSection);
			optionsRow.appendChild(optionsSubmenu);

			// Hover to open submenu (same mechanics as V/A/S rows)
			optionsRow.addEventListener("mouseenter", () => {
				this.element
					.querySelectorAll(".ytdlp-component-row.submenu-open")
					.forEach((r) => {
						if (r !== optionsRow) r.classList.remove("submenu-open");
					});
				optionsRow.classList.add("submenu-open");
				requestAnimationFrame(() => {
					try {
						const rowRect = optionsRow.getBoundingClientRect();
						const submenuRect = optionsSubmenu.getBoundingClientRect();
						optionsSubmenu.style.top = "0";
						optionsSubmenu.style.bottom = "";
						if (rowRect.top + submenuRect.height > window.innerHeight - 10) {
							optionsSubmenu.style.top = "auto";
							optionsSubmenu.style.bottom = "0";
						}
					} catch (_e) {
						/* ignore */
					}
				});
			});

			optionsRow.addEventListener("mouseleave", () => {
				optionsRow.classList.remove("submenu-open");
			});

			this.element.appendChild(optionsRow);

			// ─────────────────────────────────────────────────────────────
			// DOWNLOAD BUTTON
			// ─────────────────────────────────────────────────────────────
			downloadBtn = document.createElement("div");
			downloadBtn.className = "ytdlp-download-btn";
			downloadBtn.textContent = "⬇ Download";

			downloadBtn.onclick = (e) => {
				e.preventDefault();
				e.stopPropagation();
				if (downloadBtn.classList.contains("disabled")) return;
				if (!validateSettings().valid) return;
				onDownload("media");
			};

			this.element.appendChild(downloadBtn);
			updateDownloadState();

			// ─────────────────────────────────────────────────────────────
			// SUPPORT BUTTON
			// ─────────────────────────────────────────────────────────────
			const supportBtn = document.createElement("a");
			supportBtn.className = "ytdlp-support-btn";
			supportBtn.href = "https://ko-fi.com/piknockyou";
			supportBtn.target = "_blank";
			supportBtn.rel = "noopener noreferrer";
			supportBtn.textContent = "☕ Support";
			supportBtn.setAttribute(
				"data-tooltip",
				["𝘆𝘁-𝗱𝗹𝗽 𝗦𝘂𝗽𝗽𝗼𝗿𝘁", "", "Open Ko-Fi page"].join("\n"),
			);
			supportBtn.addEventListener("click", (e) => {
				e.stopPropagation();
			});
			supportBtn.addEventListener("mouseenter", () =>
				repositionTooltip(supportBtn),
			);
			supportBtn.addEventListener("mouseleave", () =>
				supportBtn.classList.remove("ytdlp-tooltip-right"),
			);

			this.element.appendChild(supportBtn);

			// Initial update of all states
			updateAllStates();

			// Position menu
			this.element.classList.add("visible");
			requestAnimationFrame(() => {
				try {
					const rect = this.element.getBoundingClientRect();
					let left = x - rect.width - 10;
					let top = y;
					if (left < 10) left = 10;
					if (top + rect.height > window.innerHeight - 10)
						top = window.innerHeight - rect.height - 10;
					if (top < 10) top = 10;
					this.element.style.left = `${left}px`;
					this.element.style.top = `${top}px`;
				} catch (_e) {
					this.element.style.left = "10px";
					this.element.style.top = "10px";
				}
			});

			// Outside click handler (only way to close)
			if (this.closeHandler) {
				document.removeEventListener("mousedown", this.closeHandler, true);
			}

			this.closeHandler = (e) => {
				if (!this.isOpen) return;
				try {
					if (e.composedPath().includes(this.shadowHost)) return;
				} catch (_err) {
					// composedPath might fail in some edge cases
					if (this.shadowHost.contains(e.target)) return;
				}
				this.hide();
			};
			setTimeout(
				() => document.addEventListener("mousedown", this.closeHandler, true),
				100,
			);
		},

		hide() {
			if (this.element) {
				this.element.classList.remove("visible");
			}
			this.isOpen = false;
			this.updateFunctions = [];
			if (this.closeHandler) {
				document.removeEventListener("mousedown", this.closeHandler, true);
				this.closeHandler = null;
			}
		},

		isVisible() {
			return this.isOpen;
		},
	};

	//================================================================================
	// PYTHON SCRIPT GENERATION
	//================================================================================

	const CONFIG_UI = {
		button: {
			size: 24,
			iconStyle: {
				shadow: { enabled: true, blur: 2, color: "rgba(255, 255, 255, 0.8)" },
				background: {
					enabled: true,
					color: "rgba(128, 128, 128, 0.25)",
					borderRadius: "50%",
				},
			},
			position: {
				vertical: "bottom",
				horizontal: "right",
				offsetX: 1,
				offsetY: 29,
			},
			opacity: { default: 0.15, hover: 1 },
			scale: { default: 1, hover: 1.1 },
			zIndex: 2147483646,
		},
		timing: {
			doubleClickThreshold: 350,
			hideTemporarilyDuration: 5000,
			hoverCheckInterval: 100,
		},
	};

	//================================================================================
	// GLOBAL STATE
	//================================================================================

	const hostname = window.location.hostname;
	const complex = COMPLEX_SITES[hostname];
	const siteCondition = SITE_CONDITIONS[hostname];
	const COOKIE_FILE = complex?.cookieFile || `${hostname}_cookies.txt`;

	let shadowRoot = null;
	let notificationShadowRoot = null;
	let notificationElement = null;
	let containerElement = null;

	const STATE = {
		hidden: false,
		lastUrl: window.location.href,
		checkInterval: null,
	};

	//================================================================================
	// HELPER FUNCTIONS
	//================================================================================

	const sanitize = (str, max = 80) =>
		(str || "video")
			.replace(/[^a-zA-Z0-9]/g, "_")
			.replace(/_+/g, "_")
			.substring(0, max);

	function getVideoInfo() {
		const url = window.location.href;

		if (complex?.extractUrl) {
			const result = complex.extractUrl();
			if (result.error) return result;
			return {
				url: result.url,
				filename: sanitize(document.title),
				cookieFile: COOKIE_FILE,
			};
		}
		return {
			url: url,
			filename: sanitize(document.title),
			cookieFile: COOKIE_FILE,
		};
	}

	const getOverwriteFlag = () => (FORCE_OVERWRITE ? "--force-overwrites" : "");

	// Helper to convert JS boolean to Python boolean string
	const pyBool = (val) => (val ? "True" : "False");

	// ═══════════════════════════════════════════════════════════════
	// Python script header template
	// ═══════════════════════════════════════════════════════════════
	function getPythonHeader() {
		return `#!/usr/bin/env python3
"""
yt-dlp Media Downloader
Generated by yt-dlp Python-Downloader userscript
Cross-platform: Works on Windows, Mac, and Linux
Requires: Python 3.6+, yt-dlp
Optional: mkvmerge (for advanced merging), ffmpeg/ffprobe
"""

import subprocess
import sys
import os
import shutil
import random
from pathlib import Path
from glob import glob
import re

# ════════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ════════════════════════════════════════════════════════════════════════════════

def ytdlp_base():
    """Return base yt-dlp command with --restrict-filenames for ASCII-safe output."""
    return ["yt-dlp", "--restrict-filenames"]

def print_header(title):
    """Print a formatted header."""
    print()
    print("=" * 60)
    print(f"  {title}")
    print("=" * 60)
    print()

def print_status(status, message):
    """Print a status message."""
    print(f"[{status}] {message}")

def check_command(cmd):
    """Check if a command is available in PATH."""
    return shutil.which(cmd) is not None

def require_ytdlp(show_platform_hints=True):
    """Exit with a helpful message if yt-dlp is not installed."""
    if not check_command("yt-dlp"):
        print_status("ERROR", "yt-dlp not found")
        print("Install: pip install yt-dlp")
        if show_platform_hints:
            print("     or: brew install yt-dlp (Mac)")
            print("     or: winget install yt-dlp (Windows)")
        wait_for_exit()
        sys.exit(1)
    print_status("OK", "yt-dlp found")

def get_cookies_arg(cookie_file):
    """
    Return ['--cookies', cookie_file] if a cookie file exists, else [] (and print status).

    For YouTube/YouTube Music, users commonly export cookies under a shared filename
    like youtube.com_cookies.txt. If the expected host-specific cookie file isn't
    present, try a few common alternates automatically.
    """
    candidates = [cookie_file]

    try:
        url = (globals().get("URL", "") or "").lower()
        if "youtube.com" in url or "youtu.be" in url:
            candidates.extend([
                "youtube.com_cookies.txt",
                "www.youtube.com_cookies.txt",
                "music.youtube.com_cookies.txt",
            ])
    except Exception:
        pass

    seen = set()
    for c in candidates:
        if not c or c in seen:
            continue
        seen.add(c)
        if Path(c).exists():
            print_status("OK", f"Cookie file found: {c}")
            return ["--cookies", c]

    print_status("INFO", "No cookie file")
    return []

def build_base_cmd(overwrite_flag="", referer="", needs_impersonate=False, cookies_arg=None, extra_args=None):
    """Build base yt-dlp command with common flags."""
    cmd = ytdlp_base()
    if extra_args:
        cmd.extend(extra_args)
    if overwrite_flag:
        cmd.append(overwrite_flag)
    if referer:
        cmd.extend(["--referer", referer])
    if needs_impersonate:
        cmd.extend(["--impersonate", "chrome"])
    if cookies_arg:
        cmd.extend(cookies_arg)
    return cmd

def sanitize_filename(name, max_len=120):
    """
    Make a filename safe across Windows/macOS/Linux while keeping it readable.
    Strips non-ASCII characters, replaces forbidden characters, collapses whitespace,
    trims trailing dots/spaces, and limits length.
    """
    if not name:
        return "video"

    # Strip non-ASCII characters (prevents Unicode/RTL filename issues on Windows)
    name = name.encode("ascii", errors="ignore").decode("ascii")

    # Windows-forbidden + control chars
    name = re.sub(r'[<>:"/\\\\|?*\\x00-\\x1f]', "_", name)

    # Collapse runs of whitespace and underscores
    name = re.sub(r'\\s+', " ", name).strip()
    name = re.sub(r'_+', "_", name).strip("_ ")

    # Windows doesn't like trailing dots/spaces
    name = name.rstrip(". ")

    if not name:
        return "video"

    if len(name) > max_len:
        name = name[:max_len].rstrip(". ")

    return name or "video"

def is_playlist_url(url):
    """
    Check if URL appears to be a playlist.
    Returns True if URL contains common playlist indicators.
    """
    playlist_indicators = [
        '/sets/',           # SoundCloud playlists
        '/playlist',        # YouTube, Spotify
        '?list=',           # YouTube playlist parameter
        '&list=',           # YouTube playlist parameter
        '/album/',          # Music albums
        '/albums/',         # Music albums
    ]
    url_lower = url.lower()
    return any(indicator in url_lower for indicator in playlist_indicators)

def get_output_template(include_id=True):
    """
    Return yt-dlp output template for downloaded files.
    Uses yt-dlp variables so each playlist item gets unique name.
    Format: Artist - Title [ID].ext (best practice for music files)
    """
    if include_id:
        return "%(uploader)s - %(title)s [%(id)s].%(ext)s"
    else:
        return "%(uploader)s - %(title)s.%(ext)s"

def resolve_output_name(url, cookies_arg, fallback, needs_impersonate=False, impersonate_target="chrome", referer="", include_id=True):
    """
    Resolve a better output base name using yt-dlp metadata (title + id).
    Falls back to the provided fallback name if anything fails.
    NOTE: Used for display purposes only. Actual downloads use get_output_template().
    """
    try:
        template = "%(title)s [%(id)s]" if include_id else "%(title)s"
        cmd = ytdlp_base() + ["--no-playlist", "--print", template]

        if referer:
            cmd.extend(["--referer", referer])

        if needs_impersonate:
            cmd.extend(["--impersonate", impersonate_target])

        cmd.extend(cookies_arg)
        cmd.append(url)

        result = subprocess.run(cmd, capture_output=True, text=True)
        out = (result.stdout or "").strip()

        # Use last non-empty line (some extractors print extra stuff)
        lines = [l.strip() for l in out.splitlines() if l.strip()]
        if result.returncode == 0 and lines:
            return sanitize_filename(lines[-1])
    except Exception:
        pass

    return fallback

def wait_for_exit():
    """Wait for user to press Enter before exiting."""
    print()
    print("Press Enter to exit...")
    try:
        input()
    except:
        pass

def cleanup_and_exit():
    """Cleanup files if configured, then wait for user to press Enter."""
    if "CLEANUP_COOKIE" in globals() and CLEANUP_COOKIE and Path(COOKIE_FILE).exists():
        try:
            Path(COOKIE_FILE).unlink()
            print_status("INFO", "Cookie file removed")
        except Exception as e:
            print_status("WARNING", f"Could not remove cookie file: {e}")
    if "CLEANUP_SCRIPT" in globals() and CLEANUP_SCRIPT:
        try:
            Path(__file__).unlink()
            print_status("INFO", "Script file removed")
        except Exception as e:
            print_status("WARNING", f"Could not remove script file: {e}")
    wait_for_exit()

def safe_main(main_func):
    """
    Run main_func() with a catch-all so the console window never vanishes
    silently on Windows when an unhandled exception fires before wait_for_exit().
    """
    try:
        main_func()
    except KeyboardInterrupt:
        print()
        print_status("INFO", "Interrupted by user")
        wait_for_exit()
    except Exception as e:
        print()
        print(f"[ERROR] Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        wait_for_exit()

def resolve_vimeo_embed_referer(url, existing_referer):
    """
    For player.vimeo.com embed-only videos:
    If the browser supplied a specific referer (the embedding page), use it directly.
    Otherwise probe yt-dlp to detect embed-only restriction and prompt the user.
    Returns the referer string to use (may be unchanged if not a player.vimeo.com URL).
    """
    if "player.vimeo.com" not in url:
        return existing_referer

    # If the browser captured a real embedding-page referer, use it directly.
    # A generic 'https://vimeo.com/' referer is not useful — skip it.
    if existing_referer and existing_referer not in ("https://vimeo.com/", "https://vimeo.com"):
        print_status("INFO", f"Vimeo embed referer: {existing_referer}")
        return existing_referer

    # No useful referer — probe first to see if the video is embed-only.
    print_status("INFO", "Checking if Vimeo video requires an embedding URL...")
    probe_cmd = ytdlp_base() + ["--skip-download", "--print", "%(id)s", "--no-playlist", url]
    if existing_referer:
        probe_cmd.extend(["--referer", existing_referer])
    probe = subprocess.run(probe_cmd, capture_output=True, text=True)
    combined = (probe.stdout + probe.stderr).lower()

    if "embed-only" not in combined and "embedding url" not in combined:
        return existing_referer  # Not embed-only, proceed normally.

    print()
    print_status("WARN", "This is an embed-only Vimeo video")
    print()
    print("  yt-dlp needs the URL of the page that embeds this video.")
    print("  1. Open the page where you watched this video in your browser")
    print("  2. Copy its URL from the address bar")
    print("  3. Paste it below")
    print()
    embed_url = input("  Embedding page URL (or Enter to try anyway): ").strip()
    print()
    return embed_url or existing_referer

def identify_file(filepath, has_ffprobe=False):
    """
    Identify if a file is video, audio, or subtitle based on extension and filename hints.
    Uses format_id in filename (e.g., 'hls-audio-128000') to detect audio streams.
    For ambiguous formats, uses ffprobe if available.
    Returns: 'video', 'audio', 'subtitle', or 'unknown'
    """
    path = Path(filepath)
    name = path.stem.lower()
    ext = path.suffix.lower()

    # Check for subtitle marker in filename
    if "_sub" in name:
        return "subtitle"

    # Check for audio marker in format_id (e.g., "hls-audio-128000-Audio")
    # This catches HLS audio streams that have .mp4 extension
    if "audio" in name and "video" not in name:
        return "audio"

    # Audio-only extensions
    audio_exts = {".m4a", ".mp3", ".opus", ".ogg", ".aac", ".flac", ".wav"}
    if ext in audio_exts:
        return "audio"

    # Unambiguous video extensions
    video_exts = {".mkv", ".avi", ".mov", ".flv", ".ts", ".3gp"}
    if ext in video_exts:
        return "video"

    # Ambiguous extensions (.webm and .mp4 can be video or audio-only)
    if ext in {".webm", ".mp4"}:
        if has_ffprobe:
            try:
                result = subprocess.run(
                    ["ffprobe", "-v", "error", "-select_streams", "v:0",
                     "-show_entries", "stream=codec_type", "-of", "csv=p=0", filepath],
                    capture_output=True, text=True, timeout=10
                )
                if "video" in result.stdout.lower():
                    return "video"
                else:
                    return "audio"
            except:
                pass
        # Without ffprobe, return unknown (not "video") to trigger Tier 2 fallback
        return "unknown"

    return "unknown"

def probe_format_ids(url, video_format, audio_format, cookies_arg, referer="", needs_impersonate=False, codec_arg=""):
    """
    Tier 2 identification: Ask yt-dlp which format IDs it selected.
    Runs a single --print query with the combined format string.
    Must include the same codec_arg used during download so the resolved
    format IDs match what was actually downloaded.
    Returns dict mapping format_id -> 'video' or 'audio', or empty dict on failure.
    """
    formats = []
    labels = []
    if video_format:
        formats.append(video_format)
        labels.append("video")
    if audio_format:
        formats.append(audio_format)
        labels.append("audio")

    if not formats:
        return {}

    format_str = ",".join(formats)
    cmd = ytdlp_base() + ["--no-playlist", "--print", "%(format_id)s", "-f", format_str]

    # Include codec sort arg so probe resolves same format IDs as the download
    if codec_arg:
        cmd.extend(codec_arg.split())

    if referer:
        cmd.extend(["--referer", referer])
    if needs_impersonate:
        cmd.extend(["--impersonate", "chrome"])
    cmd.extend(cookies_arg)
    cmd.append(url)

    try:
        print_status("INFO", "Probing yt-dlp for format IDs...")
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        lines = [l.strip() for l in result.stdout.strip().splitlines() if l.strip()]

        if result.returncode != 0 or len(lines) != len(labels):
            print_status("WARNING", f"Format ID probe returned {len(lines)} IDs, expected {len(labels)}")
            return {}

        mapping = {}
        for fmt_id, label in zip(lines, labels):
            mapping[fmt_id] = label
            print_status("OK", f"Format ID '{fmt_id}' -> {label}")
        return mapping
    except Exception as e:
        print_status("WARNING", f"Format ID probe failed: {e}")
        return {}

def match_format_id_from_filename(filepath, temp_base):
    """
    Extract the format_id from a temp filename.
    Filename pattern: {temp_base}.{format_id}.{ext}
    Returns the format_id string, or None if pattern doesn't match.
    """
    basename = os.path.basename(filepath)
    prefix = os.path.basename(temp_base) + "."

    if not basename.startswith(prefix):
        return None

    # Strip prefix: "format_id.ext"
    remainder = basename[len(prefix):]

    # Strip extension: "format_id"
    # Handle compound extensions like .en.vtt by only stripping the last dot-segment
    # But format_ids can contain dots too... use Path.suffix for last extension
    last_dot = remainder.rfind(".")
    if last_dot <= 0:
        return None

    format_id = remainder[:last_dot]
    return format_id if format_id else None

def identify_files_two_tier(file_list, temp_base, has_ffprobe, url, video_format, audio_format, cookies_arg, referer="", needs_impersonate=False, codec_arg=""):
    """
    Two-tier file identification:
      Tier 1: ffprobe (fast, local) via identify_file()
      Tier 2: yt-dlp format-ID probe (network, authoritative)

    Returns: (video_file, audio_file, subtitle_files)
    """
    # Step 1: Run Tier 1 (identify_file with ffprobe if available)
    results = []  # list of (filepath, file_type)
    for filepath in file_list:
        file_type = identify_file(filepath, has_ffprobe)
        results.append((filepath, file_type))
        basename = os.path.basename(filepath)
        print(f"  [Tier1: {file_type.upper()}] {basename}")

    # Step 2: Check for ambiguity
    non_sub = [(fp, ft) for fp, ft in results if ft != "subtitle"]
    has_ambiguity = (
        sum(1 for _, ft in non_sub if ft == "unknown") > 0
        or sum(1 for _, ft in non_sub if ft == "video") > 1
        or (video_format and audio_format and sum(1 for _, ft in non_sub if ft == "audio") == 0 and len(non_sub) > 1)
    )

    # Step 3: If ambiguous, run Tier 2 (yt-dlp format-ID probe)
    if has_ambiguity and (video_format or audio_format):
        print()
        print("  Tier 1 inconclusive - running Tier 2 (yt-dlp format-ID probe)...")
        fmt_map = probe_format_ids(url, video_format, audio_format, cookies_arg, referer, needs_impersonate, codec_arg)

        if fmt_map:
            # Re-classify using format ID mapping
            new_results = []
            for filepath, old_type in results:
                if old_type == "subtitle":
                    new_results.append((filepath, "subtitle"))
                    continue

                fmt_id = match_format_id_from_filename(filepath, temp_base)
                if fmt_id and fmt_id in fmt_map:
                    new_type = fmt_map[fmt_id]
                    if new_type != old_type:
                        print_status("OK", f"Reclassified '{os.path.basename(filepath)}': {old_type} -> {new_type} (format_id={fmt_id})")
                    new_results.append((filepath, new_type))
                else:
                    # Format ID not in mapping - keep Tier 1 result
                    new_results.append((filepath, old_type))

            results = new_results

    # Step 4: Assign files (collect-then-assign, no overwrite)
    video_file = None
    audio_file = None
    subtitle_files = []

    for filepath, file_type in results:
        basename = os.path.basename(filepath)
        if file_type == "subtitle":
            subtitle_files.append(filepath)
        elif file_type == "video":
            if video_file is None:
                video_file = filepath
            elif audio_file is None:
                # Second "video" - demote to audio as last resort
                print_status("WARNING", f"Two video files detected - assigning '{basename}' as audio (fallback)")
                audio_file = filepath
            else:
                print_status("WARNING", f"Extra file: {basename} (ignored)")
        elif file_type == "audio":
            if audio_file is None:
                audio_file = filepath
            elif video_file is None:
                # Second "audio" - promote to video as last resort
                print_status("WARNING", f"Two audio files detected - assigning '{basename}' as video (fallback)")
                video_file = filepath
            else:
                print_status("WARNING", f"Extra file: {basename} (ignored)")
        else:
            # unknown - assign to first empty slot
            if video_file is None:
                video_file = filepath
                print_status("INFO", f"Unknown file '{basename}' assigned as video")
            elif audio_file is None:
                audio_file = filepath
                print_status("INFO", f"Unknown file '{basename}' assigned as audio")
            else:
                print_status("WARNING", f"Extra unknown file: {basename} (ignored)")

    # Print final assignment
    print()
    if video_file:
        print(f"  => VIDEO: {os.path.basename(video_file)}")
    if audio_file:
        print(f"  => AUDIO: {os.path.basename(audio_file)}")
    for sf in subtitle_files:
        print(f"  => SUB:   {os.path.basename(sf)}")

    return video_file, audio_file, subtitle_files

def check_subtitles_available(url, cookies_arg):
    """
    Check if subtitles are available for the video.
    Returns (sub_lang, do_subs, sub_args) tuple.
    - sub_lang: the language code entered by user (or None)
    - do_subs: True if subtitles should be downloaded
    - sub_args: list of yt-dlp arguments for subtitles
    """
    print()
    print("[INFO] Checking for available subtitles...")

    result = subprocess.run(
        ytdlp_base() + ["--list-subs"] + cookies_arg + [url],
        capture_output=True, text=True
    )

    combined_output = (result.stdout + result.stderr).lower()

    # Check if no subtitles available
    # yt-dlp may say "has no subtitles" OR just show nothing
    if "has no subtitles" in combined_output:
        print("[INFO] No subtitles available for this video")
        return None, False, []

    # Check if subtitles are actually listed (look for table indicator)
    if "available subtitles" not in combined_output:
        print("[INFO] No subtitles available for this video")
        return None, False, []

    # Subtitles are available - show them and prompt
    print()
    print_header("Available Subtitles")
    print(result.stdout)

    print()
    print("=" * 60)
    print("Enter language code (e.g., en, de, ja)")
    print("Or type 'all' for all languages")
    print("Or press Enter to skip subtitles")
    print("=" * 60)
    print()

    sub_lang = input("Language code: ").strip()

    if not sub_lang:
        print()
        print("Skipping subtitles...")
        return None, False, []

    return sub_lang, True, ["--write-subs", "--write-auto-subs", "--sub-langs", sub_lang]

`;
	}

	function generatePythonScript(
		url,
		filename,
		cookieFile,
		mode,
		deletePyAfterRun = false,
		deleteCookieAfterRun = false,
	) {
		const overwriteFlag = getOverwriteFlag();

		// ═══════════════════════════════════════════════════════════════
		// COMMENTS MODE
		// ═══════════════════════════════════════════════════════════════
		if (mode === "comments") {
			return `${getPythonHeader()}
# ════════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ════════════════════════════════════════════════════════════════════════════════

URL = "${url}"
FILENAME = "${filename}"
COOKIE_FILE = "${cookieFile}"
OVERWRITE_FLAG = "${overwriteFlag}"
CLEANUP_SCRIPT = ${pyBool(deletePyAfterRun)}
CLEANUP_COOKIE = ${pyBool(deleteCookieAfterRun)}

# ════════════════════════════════════════════════════════════════════════════════
# MAIN - Comments Download
# ════════════════════════════════════════════════════════════════════════════════

def main():
    # Change to script directory
    os.chdir(Path(__file__).parent)

    print_header("yt-dlp Comments Downloader")

    require_ytdlp(show_platform_hints=True)
    cookies_arg = get_cookies_arg(COOKIE_FILE)

    # Build command
    cmd = build_base_cmd(overwrite_flag=OVERWRITE_FLAG, cookies_arg=cookies_arg)

    print()
    print(f"URL: {URL}")
    print()

    # Add comment extraction arguments
    cmd.extend([
        URL,
        "--skip-download",
        "--write-comments",
        "--no-playlist",
        "-o", f"{FILENAME}.%(ext)s"
    ])

    # Add YouTube-specific comment sorting (only on YouTube)
    if "youtube.com" in URL or "youtu.be" in URL:
        cmd.insert(-2, "--extractor-args")
        cmd.insert(-2, "youtube:comment_sort=top;max_comments=all,all,all,all")

    # Run yt-dlp
    result = subprocess.run(cmd)

    print()
    if result.returncode != 0:
        print_status("ERROR", "Download failed")
        wait_for_exit()
        sys.exit(1)
    else:
        print_status("SUCCESS", "Comments downloaded!")
        cleanup_and_exit()

if __name__ == "__main__":
    safe_main(main)
`;
		}

		// ═══════════════════════════════════════════════════════════════
		// FORMATS MODE
		// ═══════════════════════════════════════════════════════════════
		if (mode === "formats") {
			return `${getPythonHeader()}
# ════════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ════════════════════════════════════════════════════════════════════════════════

URL = "${url}"
COOKIE_FILE = "${cookieFile}"
CLEANUP_SCRIPT = ${pyBool(deletePyAfterRun)}
CLEANUP_COOKIE = ${pyBool(deleteCookieAfterRun)}

# ════════════════════════════════════════════════════════════════════════════════
# MAIN - List Formats
# ════════════════════════════════════════════════════════════════════════════════

def main():
    # Change to script directory
    os.chdir(Path(__file__).parent)

    print_header("yt-dlp Format Listing")

    require_ytdlp(show_platform_hints=True)
    cookies_arg = get_cookies_arg(COOKIE_FILE)

    # Build command
    cmd = build_base_cmd(cookies_arg=cookies_arg, extra_args=["--list-formats"])

    cmd.append(URL)

    print()
    print(f"URL: {URL}")
    print()
    print("=" * 80)
    print()

    # Run yt-dlp
    result = subprocess.run(cmd)

    print()
    print("=" * 80)
    cleanup_and_exit()

if __name__ == "__main__":
    safe_main(main)
`;
		}

		// ═══════════════════════════════════════════════════════════════
		// THUMBNAILS MODE
		// ═══════════════════════════════════════════════════════════════
		if (mode === "thumbnails") {
			return `${getPythonHeader()}
# ════════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ════════════════════════════════════════════════════════════════════════════════

URL = "${url}"
FILENAME = "${filename}"
COOKIE_FILE = "${cookieFile}"
OVERWRITE_FLAG = "${overwriteFlag}"
CLEANUP_SCRIPT = ${pyBool(deletePyAfterRun)}
CLEANUP_COOKIE = ${pyBool(deleteCookieAfterRun)}

# ════════════════════════════════════════════════════════════════════════════════
# MAIN - Thumbnails Download
# ════════════════════════════════════════════════════════════════════════════════

def main():
    # Change to script directory
    os.chdir(Path(__file__).parent)

    print_header("yt-dlp Thumbnail Downloader")

    require_ytdlp(show_platform_hints=True)
    cookies_arg = get_cookies_arg(COOKIE_FILE)

    # Build command
    cmd = build_base_cmd(overwrite_flag=OVERWRITE_FLAG, cookies_arg=cookies_arg)

    print()
    print(f"URL: {URL}")
    print()

    # Add thumbnail extraction arguments
    # Uses --write-thumbnail for best quality single thumbnail
    # Keeps original format (webp/jpg) - no conversion needed
    cmd.extend([
        URL,
        "--skip-download",
        "--write-thumbnail",
        "--no-playlist",
        "-o", f"{FILENAME}.%(ext)s"
    ])

    print("Downloading best available thumbnail...")
    print("(yt-dlp probes from highest to lowest quality)")
    print()

    # Run yt-dlp
    result = subprocess.run(cmd)

    print()
    if result.returncode != 0:
        print_status("ERROR", "Download failed")
        wait_for_exit()
        sys.exit(1)
    else:
        # Find the downloaded thumbnail (could be .webp, .jpg, .png)
        thumbs = glob(f"{FILENAME}.webp") + glob(f"{FILENAME}.jpg") + glob(f"{FILENAME}.png")
        if thumbs:
            print_status("SUCCESS", f"Saved: {thumbs[0]}")
        else:
            print_status("WARNING", "Thumbnail file not found")
        cleanup_and_exit()

if __name__ == "__main__":
    safe_main(main)
`;
		}

		// ═══════════════════════════════════════════════════════════════
		// MEDIA MODE
		// ═══════════════════════════════════════════════════════════════
		const videoQuality = getVideoQuality();
		const videoCodec = getVideoCodec();
		const videoOutput = getVideoOutput();
		const audioQuality = getAudioQuality();
		const audioOutput = getAudioOutput();
		const subsFormat = getSubsFormat();
		const subsOutput = getSubsOutput();

		const hasVideo = isEnabled(videoOutput);
		const hasAudio = isEnabled(audioOutput);
		const hasSubs = isEnabled(subsOutput);

		const videoMerge = hasMergeFlag(videoOutput);
		const videoSeparate = hasSeparateFlag(videoOutput);
		const audioMerge = hasMergeFlag(audioOutput);
		const audioSeparate = hasSeparateFlag(audioOutput);
		const subsMerge = hasMergeFlag(subsOutput);
		const subsSeparate = hasSeparateFlag(subsOutput);

		// needsMerge: at least 2 components have merge flag
		const mergeCount = [videoMerge, audioMerge, subsMerge].filter(
			Boolean,
		).length;
		const needsMerge = mergeCount >= 2;

		// Build format string
		const videoFormat =
			findOption(VIDEO_QUALITIES, videoQuality)?.format || "bestvideo";
		const codecArg =
			hasVideo && isYouTubeDomain() && videoCodec !== "default"
				? findOption(VIDEO_CODECS, videoCodec)?.sortArg || ""
				: "";
		const subsConvertArg =
			findOption(SUBTITLE_FORMATS, subsFormat)?.convertArg || "";

		// Generate summary labels (codec only shown on YouTube)
		const showCodecInLabel = isYouTubeDomain() && videoCodec !== "default";
		const videoLabel = hasVideo
			? `${getLabel(VIDEO_QUALITIES, videoQuality)}${showCodecInLabel ? ` [${getLabel(VIDEO_CODECS, videoCodec)}]` : ""}`
			: "None";
		const audioCodec = getAudioCodec();

		// Build audio format with codec filter
		// Note: Uses single quotes inside yt-dlp filter syntax to avoid breaking Python strings
		const buildAudioFormat = () => {
			const baseFormat =
				findOption(AUDIO_QUALITIES, audioQuality)?.format || "bestaudio";

			if (audioCodec === "auto") {
				// Auto mode: on YouTube with video, match to video codec
				if (isYouTubeDomain() && hasVideo && videoCodec !== "default") {
					// H.264 pairs with AAC, VP9/AV1 pair with Opus
					if (videoCodec === "h264") {
						return (
							baseFormat.replace("bestaudio", "bestaudio[acodec~='^mp4a']") +
							"/" +
							baseFormat
						);
					} else {
						return (
							baseFormat.replace("bestaudio", "bestaudio[acodec='opus']") +
							"/" +
							baseFormat
						);
					}
				}
				// Non-YouTube or audio-only: use best available
				return baseFormat;
			}

			// Explicit codec selection - works on ALL sites
			const codecFilter =
				findOption(AUDIO_CODECS, audioCodec)?.formatFilter || "";
			if (codecFilter && baseFormat.includes("bestaudio")) {
				return (
					baseFormat.replace("bestaudio", `bestaudio${codecFilter}`) +
					"/" +
					baseFormat
				);
			}
			return baseFormat;
		};

		const audioFormat = buildAudioFormat();
		const showAudioCodecInLabel = audioCodec !== "auto";
		const audioLabel = hasAudio
			? `${getLabel(AUDIO_QUALITIES, audioQuality)}${showAudioCodecInLabel ? ` [${getLabel(AUDIO_CODECS, audioCodec)}]` : ""}`
			: "None";
		const subsLabel = hasSubs ? getLabel(SUBTITLE_FORMATS, subsFormat) : "None";
		const getOutputLabel = (output) => getLabel(OUTPUT_MODES, output);

		// Determine merged output extension
		const preferMp4 = getPreferMp4();
		const mergedExt = preferMp4
			? hasVideo && videoMerge
				? "mp4"
				: "m4a"
			: hasVideo && videoMerge
				? "mkv"
				: "mka";

		// Check if combined stream site
		const isCombined = isCombinedStreamSite();

		// Check if site needs impersonation
		const needsImpersonate = needsImpersonation();

		// Get referer for sites that need it (Vimeo, etc.)
		const referer = getReferer();

		return `${getPythonHeader()}
# ════════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ════════════════════════════════════════════════════════════════════════════════

URL = "${url}"
FILENAME = "${filename}"
COOKIE_FILE = "${cookieFile}"
OVERWRITE_FLAG = "${overwriteFlag}"

# Component settings
HAS_VIDEO = ${pyBool(hasVideo)}
HAS_AUDIO = ${pyBool(hasAudio)}
HAS_SUBS = ${pyBool(hasSubs)}

VIDEO_MERGE = ${pyBool(videoMerge)}
VIDEO_SEPARATE = ${pyBool(videoSeparate)}
AUDIO_MERGE = ${pyBool(audioMerge)}
AUDIO_SEPARATE = ${pyBool(audioSeparate)}
SUBS_MERGE = ${pyBool(subsMerge)}
SUBS_SEPARATE = ${pyBool(subsSeparate)}

NEEDS_MERGE = ${pyBool(needsMerge)}
MERGED_EXT = "${mergedExt}"

VIDEO_FORMAT = "${videoFormat}"
AUDIO_FORMAT = "${audioFormat}"
CODEC_ARG = "${codecArg}"
SUBS_CONVERT_ARG = "${subsConvertArg}"

IS_COMBINED_STREAM_SITE = ${pyBool(isCombined)}

# Impersonation for Cloudflare bypass (Dailymotion, etc.)
NEEDS_IMPERSONATE = ${pyBool(needsImpersonate)}

# Referer bypass (Vimeo, etc.)
REFERER = "${referer}"

# Include video ID in filename
INCLUDE_VIDEO_ID = ${pyBool(getIncludeVideoId())}

# Prefer MP4 container (requires FFmpeg, may not work with all codecs)
PREFER_MP4 = ${pyBool(preferMp4)}

# Cleanup options
CLEANUP_SCRIPT = ${pyBool(deletePyAfterRun)}
CLEANUP_COOKIE = ${pyBool(deleteCookieAfterRun)}

# Display labels
VIDEO_LABEL = "${videoLabel}"
AUDIO_LABEL = "${audioLabel}"
SUBS_LABEL = "${subsLabel}"
VIDEO_OUTPUT_LABEL = "${getOutputLabel(videoOutput)}"
AUDIO_OUTPUT_LABEL = "${getOutputLabel(audioOutput)}"
SUBS_OUTPUT_LABEL = "${getOutputLabel(subsOutput)}"

${generateDownloadFunction({
	hasVideo,
	hasAudio,
	hasSubs,
	videoMerge,
	videoSeparate,
	audioMerge,
	audioSeparate,
	subsMerge,
	subsSeparate,
	needsMerge,
	videoFormat,
	audioFormat,
	isCombined,
	preferMp4,
})}

if __name__ == "__main__":
    safe_main(main)
`;
	}

	function generateDownloadFunction(opts) {
		const {
			hasVideo,
			hasAudio,
			hasSubs,
			videoMerge,
			videoSeparate,
			audioMerge,
			audioSeparate,
			subsMerge,
			subsSeparate,
			needsMerge,
			videoFormat,
			audioFormat,
			isCombined,
			preferMp4,
		} = opts;

		// ═══════════════════════════════════════════════════════════════
		// CASE 1: Subtitles ONLY (no video, no audio)
		// ═══════════════════════════════════════════════════════════════
		if (!hasVideo && !hasAudio && hasSubs) {
			return `
# ════════════════════════════════════════════════════════════════════════════════
# MAIN - Subtitle Only Download
# ════════════════════════════════════════════════════════════════════════════════

def main():
    # Change to script directory
    os.chdir(Path(__file__).parent)

    print_header("yt-dlp Subtitle Downloader")

    require_ytdlp(show_platform_hints=False)

    # Check for cookies
    cookies_arg = get_cookies_arg(COOKIE_FILE)

    print()
    print(f"URL: {URL}")

    # Resolve Vimeo embed-only referer (auto-detects or prompts user)
    global REFERER
    REFERER = resolve_vimeo_embed_referer(URL, REFERER)

    # Check for subtitles and prompt if available
    sub_lang, do_subs, sub_args = check_subtitles_available(URL, cookies_arg)

    if not do_subs:
        print()
        print("No subtitles to download.")
        wait_for_exit()
        return

    print()
    print_header("Starting Download...")

    # Build command
    cmd = build_base_cmd(overwrite_flag=OVERWRITE_FLAG, cookies_arg=cookies_arg)
    cmd.extend([
        URL,
        "--skip-download"
    ])
    cmd.extend(sub_args)

    # Add subtitle conversion if specified
    if SUBS_CONVERT_ARG:
        cmd.extend(SUBS_CONVERT_ARG.split())

    cmd.extend(["-o", f"{FILENAME}.%(ext)s"])

    # Run download
    result = subprocess.run(cmd)

    print()
    if result.returncode != 0:
        print_status("ERROR", "Subtitle download failed")
        wait_for_exit()
        sys.exit(1)
    else:
        print_status("OK", "Subtitles downloaded")
        cleanup_and_exit()
`;
		}

		// ═══════════════════════════════════════════════════════════════
		// CASE 2: Combined stream sites (simpler approach)
		// ═══════════════════════════════════════════════════════════════
		if (isCombined) {
			let formatStr = "bestvideo+bestaudio/best";
			if (hasVideo && !hasAudio) {
				formatStr = "bestvideo/best";
			} else if (!hasVideo && hasAudio) {
				formatStr = "bestaudio/best";
			}

			return `
# ════════════════════════════════════════════════════════════════════════════════
# MAIN - Combined Stream Site Download
# ════════════════════════════════════════════════════════════════════════════════

def main():
    # Change to script directory
    os.chdir(Path(__file__).parent)

    print_header("yt-dlp Media Downloader")

    print(f"URL: {URL}")
    print()
    print("Configuration:")
    print(f"  Video:     {VIDEO_LABEL} [{VIDEO_OUTPUT_LABEL}]")
    print(f"  Audio:     {AUDIO_LABEL} [{AUDIO_OUTPUT_LABEL}]")
    print(f"  Subtitles: {SUBS_LABEL} [{SUBS_OUTPUT_LABEL}]")
    print()
    print("=" * 60)

    # Check for yt-dlp
    require_ytdlp(show_platform_hints=False)

    # Check for cookies
    cookies_arg = get_cookies_arg(COOKIE_FILE)

    # Resolve Vimeo embed-only referer (auto-detects or prompts user)
    global REFERER
    REFERER = resolve_vimeo_embed_referer(URL, REFERER)

    # Resolve better base filename from yt-dlp metadata (helps on Instagram etc.)
    global FILENAME
    FILENAME = resolve_output_name(URL, cookies_arg, FILENAME, NEEDS_IMPERSONATE, "chrome", REFERER, INCLUDE_VIDEO_ID)
    print_status("INFO", f"Output name: {FILENAME}")

    # Handle subtitles
    sub_args = []
    do_subs = False

    if HAS_SUBS:
        sub_lang, do_subs, sub_args = check_subtitles_available(URL, cookies_arg)
        if do_subs and SUBS_CONVERT_ARG:
            sub_args.extend(SUBS_CONVERT_ARG.split())

    print()
    print_header("Starting Download...")
    print("Downloading from combined-stream site...")

    # Build command
    cmd = build_base_cmd(
        overwrite_flag=OVERWRITE_FLAG,
        referer=REFERER,
        needs_impersonate=NEEDS_IMPERSONATE,
        cookies_arg=cookies_arg
    )
    cmd.extend([URL, "-f", "${formatStr}"])

    # Container format
    if PREFER_MP4:
        print_status("INFO", "MP4 output requested")
        if do_subs:
            print_status("WARNING", "MP4 has limited subtitle support - embedding may fail")
    ${hasVideo ? `cmd.extend(["--merge-output-format", "${preferMp4 ? "mp4" : "mkv"}"])` : "# No video, skip merge format"}

    if do_subs:
        cmd.extend(sub_args)
        cmd.append("--embed-subs")

    # Use yt-dlp native template so each playlist item gets unique filename
    cmd.extend(["-o", get_output_template(INCLUDE_VIDEO_ID)])

    # Run download
    result = subprocess.run(cmd)

    print()
    if result.returncode != 0:
        print_status("ERROR", "Download failed")
        wait_for_exit()
        sys.exit(1)
    else:
        print_status("OK", "Download complete")
        print()
        print(f"Saved to: {Path.cwd()}")
        cleanup_and_exit()
`;
		}

		// Build format list with /best fallback for combined-stream sites
		const formats = [];
		if (hasVideo) formats.push(videoFormat);
		if (hasAudio) formats.push(audioFormat);
		const formatStr = formats.length > 0 ? `${formats.join(",")}/best` : "best";

		// ═══════════════════════════════════════════════════════════════
		// CASE 3: No merging needed - direct download
		// ═══════════════════════════════════════════════════════════════
		if (!needsMerge) {
			return `
# ════════════════════════════════════════════════════════════════════════════════
# MAIN - Direct Download (No Merge)
# ════════════════════════════════════════════════════════════════════════════════

def main():
    # Change to script directory
    os.chdir(Path(__file__).parent)

    print_header("yt-dlp Media Downloader")

    print(f"URL: {URL}")
    print()
    print("Configuration:")
    print(f"  Video:     {VIDEO_LABEL} [{VIDEO_OUTPUT_LABEL}]")
    print(f"  Audio:     {AUDIO_LABEL} [{AUDIO_OUTPUT_LABEL}]")
    print(f"  Subtitles: {SUBS_LABEL} [{SUBS_OUTPUT_LABEL}]")
    print()
    print("=" * 60)

    # Check for yt-dlp
    require_ytdlp(show_platform_hints=False)

    # Check for ffmpeg (needed for --extract-audio post-processing)
    has_ffmpeg = check_command("ffmpeg")
    if has_ffmpeg:
        print_status("OK", "ffmpeg found")
    else:
        print_status("WARNING", "ffmpeg not found")
        if not HAS_VIDEO and HAS_AUDIO:
            print_status("ERROR", "ffmpeg is REQUIRED for audio extraction (--extract-audio)")
            print("  Install: https://ffmpeg.org/download.html")
            wait_for_exit()
            sys.exit(1)
${
	hasVideo && hasAudio
		? `
    # Check for ffprobe (for file identification when downloading V+A)
    has_ffprobe = check_command("ffprobe")
    if has_ffprobe:
        print_status("OK", "ffprobe found (Tier 1 file identification)")
    else:
        print_status("INFO", "ffprobe not found - will use yt-dlp probe for file identification")
`
		: `
    has_ffprobe = False
`
}
    # Check for cookies
    cookies_arg = get_cookies_arg(COOKIE_FILE)

    # Resolve Vimeo embed-only referer (auto-detects or prompts user)
    global REFERER
    REFERER = resolve_vimeo_embed_referer(URL, REFERER)

    # Resolve better base filename from yt-dlp metadata
    global FILENAME
    FILENAME = resolve_output_name(URL, cookies_arg, FILENAME, NEEDS_IMPERSONATE, "chrome", REFERER, INCLUDE_VIDEO_ID)
    print_status("INFO", f"Output name: {FILENAME}")

    # Handle subtitles
    sub_args = []
    do_subs = False

    if HAS_SUBS:
        sub_lang, do_subs, sub_args = check_subtitles_available(URL, cookies_arg)
        if do_subs and SUBS_CONVERT_ARG:
            sub_args.extend(SUBS_CONVERT_ARG.split())

    print()
    print_header("Starting Download...")

    components = []
    if HAS_VIDEO:
        components.append("video")
    if HAS_AUDIO:
        components.append("audio")
    if do_subs:
        components.append("subtitles")

    print(f"Downloading {' + '.join(components)}...")

    ${
			hasVideo && hasAudio
				? `
    # Check if this is a playlist - use simplified flow for playlists
    if is_playlist_url(URL):
        print_status("INFO", "Playlist detected - using yt-dlp native merge")

        cmd = ytdlp_base()
        if OVERWRITE_FLAG:
            cmd.append(OVERWRITE_FLAG)
        if REFERER:
            cmd.extend(["--referer", REFERER])
        if NEEDS_IMPERSONATE:
            cmd.extend(["--impersonate", "chrome"])
        cmd.extend(cookies_arg)
        cmd.extend([URL, "-f", "${formatStr}"])
        if CODEC_ARG:
            cmd.extend(CODEC_ARG.split())

        # Use yt-dlp native merge
        merge_fmt = "mp4" if PREFER_MP4 else "mkv"
        cmd.extend(["--merge-output-format", merge_fmt])

        if do_subs:
            cmd.extend(sub_args)
            cmd.append("--embed-subs")

        cmd.extend(["-o", get_output_template(INCLUDE_VIDEO_ID)])

        result = subprocess.run(cmd)
        print()
        if result.returncode != 0:
            print_status("ERROR", "Download failed")
            wait_for_exit()
            sys.exit(1)
        else:
            print_status("OK", "Playlist download complete")
            print()
            print(f"Saved to: {Path.cwd()}")
            wait_for_exit()
        return

    # Single video - use temp files for separate outputs
    # Both video AND audio - need to download to temp, identify, then rename
    temp_base = f"_ytdlp_tmp_{random.randint(10000, 99999)}"

    # Build command with temp output names
    cmd = ytdlp_base()
    if OVERWRITE_FLAG:
        cmd.append(OVERWRITE_FLAG)

    if REFERER:
        cmd.extend(["--referer", REFERER])

    # Add impersonation for sites that need it (Dailymotion, etc.)
    if NEEDS_IMPERSONATE:
        cmd.extend(["--impersonate", "chrome"])

    cmd.extend(cookies_arg)
    cmd.extend([URL, "-f", "${formatStr}"])

    # Add codec sorting if specified
    if CODEC_ARG:
        cmd.extend(CODEC_ARG.split())

    # Use format_id to differentiate files
    if do_subs:
        cmd.extend(sub_args)
        cmd.extend(["-o", f"{temp_base}.%(format_id)s.%(ext)s", "-o", f"subtitle:{temp_base}_sub.%(ext)s"])
    else:
        cmd.extend(["-o", f"{temp_base}.%(format_id)s.%(ext)s"])

    # Run download
    result = subprocess.run(cmd)

    if result.returncode != 0:
        print()
        print_status("ERROR", "Download failed")
        # Cleanup any temp files
        for f in glob(f"{temp_base}*.*"):
            try:
                os.remove(f)
            except:
                pass
        wait_for_exit()
        sys.exit(1)

    # Identify downloaded files using two-tier identification
    print()
    print("Identifying downloaded files...")

    all_files = glob(f"{temp_base}*.*")
    video_file, audio_file, subtitle_files = identify_files_two_tier(
        all_files, temp_base, has_ffprobe,
        URL, ${hasVideo ? "VIDEO_FORMAT" : "None"}, ${hasAudio ? "AUDIO_FORMAT" : "None"},
        cookies_arg, REFERER, NEEDS_IMPERSONATE, CODEC_ARG
    )

    # Detect combined stream: we requested both video+audio but only got one file
    is_combined_stream = HAS_VIDEO and HAS_AUDIO and video_file and not audio_file

    # Copy/process to final names
    print()
    print("Creating output files...")

    if is_combined_stream:
        # Combined stream site (TikTok, Twitter, etc.)
        # Need to split the single file into separate video and audio
        print()
        print("[INFO] Site provided combined stream - splitting video and audio...")

        if not check_command("ffmpeg"):
            print_status("WARNING", "ffmpeg not found - cannot split streams")
            print("  Install ffmpeg to properly separate video and audio")
            # Fallback: just copy the combined file as video
            ext = Path(video_file).suffix
            dest = f"{FILENAME}.video{ext}"
            shutil.copy(video_file, dest)
            print_status("OK", f"Created: {dest} (contains audio)")
        else:
            video_ext = Path(video_file).suffix.lower()

            # Extract audio (no video, copy audio codec)
            audio_ext = "m4a" if video_ext == ".mp4" else "ogg" if video_ext == ".webm" else "m4a"
            audio_dest = f"{FILENAME}.audio.{audio_ext}"
            extract_audio = subprocess.run([
                "ffmpeg", "-y", "-i", video_file,
                "-vn", "-acodec", "copy",
                audio_dest
            ], capture_output=True, text=True)

            if extract_audio.returncode == 0:
                print_status("OK", f"Created: {audio_dest}")
            else:
                print_status("ERROR", "Audio extraction failed")

            # Strip audio from video (no audio, copy video codec)
            video_dest = f"{FILENAME}.video{video_ext}"
            strip_audio = subprocess.run([
                "ffmpeg", "-y", "-i", video_file,
                "-an", "-vcodec", "copy",
                video_dest
            ], capture_output=True, text=True)

            if strip_audio.returncode == 0:
                print_status("OK", f"Created: {video_dest}")
            else:
                print_status("ERROR", "Video extraction failed")
                # Fallback: copy original (with audio)
                shutil.copy(video_file, video_dest)
                print_status("OK", f"Created: {video_dest} (contains audio)")

    else:
        # Normal case: separate streams available (YouTube, etc.)
        if video_file:
            ext = Path(video_file).suffix
            dest = f"{FILENAME}.video{ext}"
            shutil.copy(video_file, dest)
            print_status("OK", f"Created: {dest}")

        if audio_file:
            ext = Path(audio_file).suffix
            dest = f"{FILENAME}.audio{ext}"
            shutil.copy(audio_file, dest)
            print_status("OK", f"Created: {dest}")

    for sub_file in subtitle_files:
        basename = os.path.basename(sub_file)
        if "_sub." in basename:
            lang_ext = basename.split("_sub.", 1)[1]
            dest = f"{FILENAME}.{lang_ext}"
            shutil.copy(sub_file, dest)
            print_status("OK", f"Created: {dest}")

    # Cleanup temp files
    cleaned = 0
    for f in glob(f"{temp_base}*.*"):
        try:
            os.remove(f)
            cleaned += 1
        except:
            pass
    print(f"  Cleaned up {cleaned} temp file(s)")

    print()
    print_status("OK", "Download complete")
    print()
    print(f"Saved to: {Path.cwd()}")
    cleanup_and_exit()
    `
				: `
    # Single component - simple direct download
    cmd = ytdlp_base()
    if OVERWRITE_FLAG:
        cmd.append(OVERWRITE_FLAG)

    if REFERER:
        cmd.extend(["--referer", REFERER])

    # Add impersonation for sites that need it (Dailymotion, etc.)
    if NEEDS_IMPERSONATE:
        cmd.extend(["--impersonate", "chrome"])

    cmd.extend(cookies_arg)
    cmd.extend([URL, "-f", "${formatStr}"])

    # Add codec sorting if specified
    if CODEC_ARG:
        cmd.extend(CODEC_ARG.split())

    # Audio-only: use --extract-audio for sites without separate audio streams
    # This uses ffmpeg stream copy (no re-encoding) - fast and lossless
    if not HAS_VIDEO and HAS_AUDIO:
        cmd.extend(["--extract-audio", "--audio-quality", "0"])

    # Use yt-dlp native template so each playlist item gets unique filename
    output_template = get_output_template(INCLUDE_VIDEO_ID)
    cmd.extend(["-o", output_template])

    # Add subtitle args if enabled
    if do_subs:
        cmd.extend(sub_args)
        cmd.extend(["-o", f"subtitle:{output_template}"])

    # Run download
    result = subprocess.run(cmd)

    print()
    if result.returncode != 0:
        print_status("ERROR", "Download failed")
        wait_for_exit()
        sys.exit(1)
    else:
        print_status("OK", "Download complete")
        print()
        print(f"Saved to: {Path.cwd()}")
        cleanup_and_exit()
    `
		}
`;
		}

		// ═══════════════════════════════════════════════════════════════
		// CASE 4: Merging required - complex multi-phase download
		// ═══════════════════════════════════════════════════════════════
		return `
# ════════════════════════════════════════════════════════════════════════════════
# MAIN - Multi-Phase Download with Merge
# ════════════════════════════════════════════════════════════════════════════════

def main():
    # Change to script directory
    os.chdir(Path(__file__).parent)

    print_header("yt-dlp Media Downloader")

    print(f"URL: {URL}")
    print()
    print("Configuration:")
    print(f"  Video:     {VIDEO_LABEL} [{VIDEO_OUTPUT_LABEL}]")
    print(f"  Audio:     {AUDIO_LABEL} [{AUDIO_OUTPUT_LABEL}]")
    print(f"  Subtitles: {SUBS_LABEL} [{SUBS_OUTPUT_LABEL}]")
    print()
    print("=" * 60)

    # === Check tools ===
    require_ytdlp(show_platform_hints=False)

    # Check for ffmpeg
    has_ffmpeg = check_command("ffmpeg")
    if has_ffmpeg:
        print_status("OK", "ffmpeg found")
    else:
        print_status("WARNING", "ffmpeg not found - some operations may fail")
        print("  Install: https://ffmpeg.org/download.html")

    # Check for mkvmerge
    has_mkvmerge = check_command("mkvmerge")
    if has_mkvmerge:
        print_status("OK", "mkvmerge found")
    else:
        if not has_ffmpeg:
            print_status("ERROR", "Neither mkvmerge nor ffmpeg found - cannot merge files")
            print("  Install mkvmerge: https://mkvtoolnix.download/")
            print("  Or install ffmpeg: https://ffmpeg.org/download.html")
            wait_for_exit()
            sys.exit(1)
        print_status("INFO", "mkvmerge not found - using FFmpeg for merge")

    # Check for ffprobe (for file identification)
    has_ffprobe = check_command("ffprobe")
    if has_ffprobe:
        print_status("OK", "ffprobe found (Tier 1 file identification)")
    else:
        print_status("INFO", "ffprobe not found - will use yt-dlp probe for file identification")

    # Check for cookies
    cookies_arg = get_cookies_arg(COOKIE_FILE)

    # Resolve Vimeo embed-only referer (auto-detects or prompts user)
    global REFERER
    REFERER = resolve_vimeo_embed_referer(URL, REFERER)

    # Resolve better base filename from yt-dlp metadata (helps on Instagram etc.)
    global FILENAME
    FILENAME = resolve_output_name(URL, cookies_arg, FILENAME, NEEDS_IMPERSONATE, "chrome", REFERER, INCLUDE_VIDEO_ID)
    print_status("INFO", f"Output name: {FILENAME}")

    # Handle subtitles
    sub_args = []
    do_subs = False

    if HAS_SUBS:
        sub_lang, do_subs, sub_args = check_subtitles_available(URL, cookies_arg)
        if do_subs and SUBS_CONVERT_ARG:
            sub_args.extend(SUBS_CONVERT_ARG.split())

    print()
    print_header("Starting Download...")

    # Check if this is a playlist - use simplified flow for playlists
    if is_playlist_url(URL):
        print_status("INFO", "Playlist detected - using yt-dlp native merge")

        # Handle subtitles
        sub_args_playlist = []
        do_subs_playlist = False
        if HAS_SUBS:
            sub_lang, do_subs_playlist, sub_args_playlist = check_subtitles_available(URL, cookies_arg)
            if do_subs_playlist and SUBS_CONVERT_ARG:
                sub_args_playlist.extend(SUBS_CONVERT_ARG.split())

        cmd = ytdlp_base()
        if OVERWRITE_FLAG:
            cmd.append(OVERWRITE_FLAG)
        if REFERER:
            cmd.extend(["--referer", REFERER])
        if NEEDS_IMPERSONATE:
            cmd.extend(["--impersonate", "chrome"])
        cmd.extend(cookies_arg)
        cmd.extend([URL, "-f", "${formatStr}"])
        if CODEC_ARG:
            cmd.extend(CODEC_ARG.split())

        # Use yt-dlp native merge
        merge_fmt = "mp4" if PREFER_MP4 else "mkv"
        cmd.extend(["--merge-output-format", merge_fmt])

        if do_subs_playlist:
            cmd.extend(sub_args_playlist)
            cmd.append("--embed-subs")

        cmd.extend(["-o", get_output_template(INCLUDE_VIDEO_ID)])

        result = subprocess.run(cmd)
        print()
        if result.returncode != 0:
            print_status("ERROR", "Download failed")
            wait_for_exit()
            sys.exit(1)
        else:
            print_status("OK", "Playlist download complete")
            print()
            print(f"Saved to: {Path.cwd()}")
            cleanup_and_exit()
        return

    # Single video - use complex merge flow with temp files
    # Generate unique temp prefix
    temp_base = f"_ytdlp_tmp_{random.randint(10000, 99999)}"
    dl_error = False

    # ════════════════════════════════════════════════════════════════════════════
    # PHASE 1: Download all components in ONE call (single metadata fetch)
    # ════════════════════════════════════════════════════════════════════════════
    print()
    print("[PHASE 1] Downloading all components...")

    cmd = ytdlp_base()
    if OVERWRITE_FLAG:
        cmd.append(OVERWRITE_FLAG)

    if REFERER:
        cmd.extend(["--referer", REFERER])

    # Add impersonation for sites that need it (Dailymotion, etc.)
    if NEEDS_IMPERSONATE:
        cmd.extend(["--impersonate", "chrome"])

    cmd.extend(cookies_arg)
    cmd.extend([URL, "-f", "${formatStr}"])

    # Add codec sorting if specified
    if CODEC_ARG:
        cmd.extend(CODEC_ARG.split())

    # Add subtitle args if enabled
    if do_subs:
        cmd.extend(sub_args)
        cmd.extend(["-o", f"{temp_base}.%(format_id)s.%(ext)s", "-o", f"subtitle:{temp_base}_sub.%(ext)s"])
    else:
        cmd.extend(["-o", f"{temp_base}.%(format_id)s.%(ext)s"])

    result = subprocess.run(cmd)

    if result.returncode != 0:
        dl_error = True
        print()
        print_status("ERROR", "Download failed")
        # Cleanup any temp files
        for f in glob(f"{temp_base}*.*"):
            try:
                os.remove(f)
            except:
                pass
        wait_for_exit()
        sys.exit(1)

    # ════════════════════════════════════════════════════════════════════════════
    # PHASE 2: Identify downloaded files
    # ════════════════════════════════════════════════════════════════════════════
    print()
    print("[PHASE 2] Identifying downloaded files...")

    all_files = glob(f"{temp_base}*.*")
    video_file, audio_file, subtitle_files = identify_files_two_tier(
        all_files, temp_base, has_ffprobe,
        URL, ${hasVideo ? "VIDEO_FORMAT" : "None"}, ${hasAudio ? "AUDIO_FORMAT" : "None"},
        cookies_arg, REFERER, NEEDS_IMPERSONATE, CODEC_ARG
    )

    # Detect combined stream: we requested both video+audio but only got one file
    is_combined_stream = HAS_VIDEO and HAS_AUDIO and video_file and not audio_file

    if is_combined_stream:
        print()
        print("[INFO] Site provided combined stream - splitting before merge...")

        if not check_command("ffmpeg"):
            print_status("WARNING", "ffmpeg not found - cannot split streams")
            print("  Merge will only contain video track")
        else:
            video_ext = Path(video_file).suffix.lower()

            # Extract audio to separate file
            audio_ext = "m4a" if video_ext == ".mp4" else "ogg" if video_ext == ".webm" else "m4a"
            audio_file = f"{temp_base}.extracted_audio.{audio_ext}"
            extract_audio = subprocess.run([
                "ffmpeg", "-y", "-i", video_file,
                "-vn", "-acodec", "copy",
                audio_file
            ], capture_output=True, text=True)

            if extract_audio.returncode == 0:
                print_status("OK", f"Extracted audio: {os.path.basename(audio_file)}")
            else:
                print_status("ERROR", "Audio extraction failed")
                audio_file = None

            # Strip audio from video file (replace in place)
            video_only = f"{temp_base}.video_only{video_ext}"
            strip_audio = subprocess.run([
                "ffmpeg", "-y", "-i", video_file,
                "-an", "-vcodec", "copy",
                video_only
            ], capture_output=True, text=True)

            if strip_audio.returncode == 0:
                # Replace original with stripped version
                try:
                    os.remove(video_file)
                    video_file = video_only
                    print_status("OK", f"Stripped audio from video")
                except:
                    video_file = video_only
            else:
                print_status("WARNING", "Could not strip audio from video")
    else:
        # Normal case - verify we found expected files
        ${
					hasVideo
						? `
        if not video_file:
            print_status("WARNING", "Expected video file not found")
        `
						: ""
				}
        ${
					hasAudio
						? `
        if not audio_file:
            print_status("WARNING", "Expected audio file not found")
        `
						: ""
				}

    # ════════════════════════════════════════════════════════════════════════════
    # PHASE 3: Merge files (only components with Merge flag)
    # ════════════════════════════════════════════════════════════════════════════
    print()
    print("[PHASE 3] Merging selected components...")

    # Determine merge tool: MP4 requires FFmpeg (mkvmerge only produces MKV/MKA)
    use_mkvmerge = has_mkvmerge and not PREFER_MP4

    if PREFER_MP4:
        print_status("INFO", "MP4 output requested")
        if not check_command("ffmpeg"):
            print_status("WARNING", "FFmpeg required for MP4 - falling back to MKV with mkvmerge")
            use_mkvmerge = has_mkvmerge
        else:
            print_status("INFO", "Using FFmpeg for MP4 merge")
            if do_subs and subtitle_files:
                print_status("WARNING", "MP4 subtitle support is limited - may not embed correctly")
            print_status("WARNING", "MP4 may fail with VP9/AV1 video or Opus audio - use H.264+AAC for best results")

    if use_mkvmerge:
        mkv_inputs = []
        merge_has_video = False
        merge_has_audio = False

        ${
					videoMerge && hasVideo
						? `
        if video_file:
            mkv_inputs.append(video_file)
            merge_has_video = True
            print("  Adding to merge: VIDEO")
        `
						: "# Video not included in merge"
				}

        ${
					audioMerge && hasAudio
						? `
        if audio_file:
            mkv_inputs.append(audio_file)
            merge_has_audio = True
            print("  Adding to merge: AUDIO")
        `
						: "# Audio not included in merge"
				}

        ${
					subsMerge && hasSubs
						? `
        if do_subs:
            for sub_file in subtitle_files:
                mkv_inputs.append(sub_file)
                print(f"  Adding to merge: {os.path.basename(sub_file)}")
        `
						: "# Subtitles not included in merge"
				}

        if len(mkv_inputs) >= 2:
            print()
            print("  Running mkvmerge...")

            # Determine actual extension based on what we have
            actual_ext = MERGED_EXT
            if not video_file and audio_file:
                # Audio only - use audio's native extension
                actual_ext = Path(audio_file).suffix.lstrip('.') or 'mka'

            merge_cmd = ["mkvmerge", "-o", f"{FILENAME}.{actual_ext}"] + mkv_inputs
            merge_result = subprocess.run(merge_cmd)

            if merge_result.returncode != 0:
                print_status("ERROR", "mkvmerge failed")
                dl_error = True
            else:
                print_status("OK", f"Created: {FILENAME}.{actual_ext}")

        elif len(mkv_inputs) == 1:
            # Only one component for merge - check if Phase 4 will create it as separate
            skip_direct_save = False
            if merge_has_video and VIDEO_SEPARATE:
                skip_direct_save = True
                print_status("INFO", "Only video for merge - will be saved as separate copy")
            elif merge_has_audio and AUDIO_SEPARATE:
                skip_direct_save = True
                print_status("INFO", "Only audio for merge - will be saved as separate copy")

            if not skip_direct_save:
                src_ext = Path(mkv_inputs[0]).suffix
                dest_file = f"{FILENAME}{src_ext}"
                print_status("INFO", "Only 1 component available - saving directly")
                shutil.copy(mkv_inputs[0], dest_file)
                print_status("OK", f"Created: {dest_file}")

        else:
            print_status("WARNING", "No components to merge")
            dl_error = True

    else:
        # FFmpeg path - either fallback (no mkvmerge) or required (MP4 output)
        if PREFER_MP4:
            print("  Using FFmpeg for MP4 output...")
        else:
            print("  mkvmerge not found - using FFmpeg to merge temp files...")

        if not check_command("ffmpeg"):
            print_status("ERROR", "FFmpeg not found!")
            if PREFER_MP4:
                print("  FFmpeg is required for MP4 output")
            print("  Install ffmpeg: https://ffmpeg.org/download.html")
            if not PREFER_MP4:
                print("  Or install mkvmerge: https://mkvtoolnix.download/")
            dl_error = True
        else:
            # Build FFmpeg command to merge the temp files we already downloaded
            ffmpeg_cmd = ["ffmpeg", "-y"]  # -y to overwrite without prompting

            input_idx = 0
            map_args = []
            codec_args = ["-c:v", "copy", "-c:a", "copy"]  # Copy video/audio without re-encoding
            merge_has_video = False
            merge_has_audio = False
            has_subs_input = False

            ${
							videoMerge && hasVideo
								? `
            if video_file:
                ffmpeg_cmd.extend(["-i", video_file])
                map_args.extend(["-map", f"{input_idx}:v"])
                input_idx += 1
                merge_has_video = True
            `
								: "# Video not included in merge"
						}

            ${
							audioMerge && hasAudio
								? `
            if audio_file:
                ffmpeg_cmd.extend(["-i", audio_file])
                map_args.extend(["-map", f"{input_idx}:a"])
                input_idx += 1
                merge_has_audio = True
            `
								: "# Audio not included in merge"
						}

            ${
							subsMerge && hasSubs
								? `
            if do_subs:
                for sub_file in subtitle_files:
                    ffmpeg_cmd.extend(["-i", sub_file])
                    map_args.extend(["-map", f"{input_idx}:s"])
                    input_idx += 1
                    has_subs_input = True
            `
								: "# Subtitles not included in merge"
						}

            if input_idx >= 2:
                ffmpeg_cmd.extend(map_args)
                ffmpeg_cmd.extend(codec_args)

                # For MP4, subtitles must be converted to mov_text (can't stream copy VTT/SRT)
                if has_subs_input:
                    if PREFER_MP4:
                        ffmpeg_cmd.extend(["-c:s", "mov_text"])
                        print("  Converting subtitles to mov_text for MP4...")
                    else:
                        ffmpeg_cmd.extend(["-c:s", "copy"])

                # Determine output extension
                actual_ext = MERGED_EXT
                if not video_file and audio_file:
                    actual_ext = Path(audio_file).suffix.lstrip('.') or ('m4a' if PREFER_MP4 else 'mka')

                output_file = f"{FILENAME}.{actual_ext}"
                ffmpeg_cmd.append(output_file)

                print()
                print(f"  Running FFmpeg merge...")
                ffmpeg_result = subprocess.run(ffmpeg_cmd, capture_output=True, text=True)

                if ffmpeg_result.returncode != 0:
                    print_status("ERROR", "FFmpeg merge failed")
                    if ffmpeg_result.stderr:
                        # Show last 300 chars which usually contains the actual error
                        error_tail = ffmpeg_result.stderr.strip()[-300:]
                        print(f"  ...{error_tail}")
                    dl_error = True
                else:
                    print_status("OK", f"Created: {output_file}")

            elif input_idx == 1:
                # Only one component for merge - check if Phase 4 will create it as separate
                skip_direct_save = False
                if merge_has_video and VIDEO_SEPARATE:
                    skip_direct_save = True
                    print_status("INFO", "Only video for merge - will be saved as separate copy")
                elif merge_has_audio and AUDIO_SEPARATE:
                    skip_direct_save = True
                    print_status("INFO", "Only audio for merge - will be saved as separate copy")

                if not skip_direct_save:
                    src_file = video_file if merge_has_video else audio_file
                    if src_file:
                        src_ext = Path(src_file).suffix
                        dest_file = f"{FILENAME}{src_ext}"
                        print_status("INFO", "Only 1 component - saving directly")
                        shutil.copy(src_file, dest_file)
                        print_status("OK", f"Created: {dest_file}")
                    else:
                        print_status("WARNING", "No components to merge")
                        dl_error = True
            else:
                print_status("WARNING", "No components to merge")
                dl_error = True

    # ════════════════════════════════════════════════════════════════════════════
    # PHASE 4: Copy files that need to be kept separately
    # ════════════════════════════════════════════════════════════════════════════
    print()
    print("[PHASE 4] Creating separate copies...")

    ${
			videoSeparate && hasVideo
				? `
    if video_file:
        ext = Path(video_file).suffix
        dest = f"{FILENAME}.video{ext}"
        try:
            shutil.copy(video_file, dest)
            print_status("OK", f"Created: {dest}")
        except Exception as e:
            print_status("ERROR", f"Failed to copy video: {e}")
    `
				: "# Video separate not requested"
		}

    ${
			audioSeparate && hasAudio
				? `
    if audio_file:
        ext = Path(audio_file).suffix
        dest = f"{FILENAME}.audio{ext}"
        try:
            shutil.copy(audio_file, dest)
            print_status("OK", f"Created: {dest}")
        except Exception as e:
            print_status("ERROR", f"Failed to copy audio: {e}")
    `
				: "# Audio separate not requested"
		}

    ${
			subsSeparate && hasSubs
				? `
    if do_subs:
        for sub_file in subtitle_files:
            # Extract lang.ext from temp_sub.lang.ext
            basename = os.path.basename(sub_file)
            # Remove the temp prefix to get lang.ext
            if "_sub." in basename:
                lang_ext = basename.split("_sub.", 1)[1]
                dest = f"{FILENAME}.{lang_ext}"
                try:
                    shutil.copy(sub_file, dest)
                    print_status("OK", f"Created: {dest}")
                except Exception as e:
                    print_status("ERROR", f"Failed to copy subtitle: {e}")
    `
				: "# Subtitle separate not requested"
		}

    # ════════════════════════════════════════════════════════════════════════════
    # PHASE 5: Cleanup temporary files
    # ════════════════════════════════════════════════════════════════════════════
    print()
    print("[PHASE 5] Cleaning up temporary files...")

    cleaned = 0
    for f in glob(f"{temp_base}*.*"):
        try:
            os.remove(f)
            cleaned += 1
        except:
            pass

    print(f"  Removed {cleaned} temporary file(s)")

    # Final status
    if dl_error:
        print()
        print("=" * 60)
        print("  [WARNING] Some operations may have failed - check messages above")
        print("=" * 60)
        wait_for_exit()
    else:
        print()
        print_status("SUCCESS", "Download complete!")
        print()
        print(f"Saved to: {Path.cwd()}")
        cleanup_and_exit()
`;
	}

	//================================================================================
	// NOTIFICATIONS
	//================================================================================

	function showNotification(message, type = "info") {
		if (!notificationShadowRoot || !notificationElement) return;
		try {
			notificationElement.classList.remove("show");
			notificationElement.textContent = message;
			notificationElement.setAttribute("data-type", type);
			void notificationElement.offsetWidth;
			notificationElement.classList.add("show");
			setTimeout(() => notificationElement.classList.remove("show"), 2500);
		} catch (e) {
			console.warn("[yt-dlp] Notification error:", e);
		}
	}

	//================================================================================
	// MAIN FUNCTIONS
	//================================================================================

	function executeDownload(mode) {
		const info = getVideoInfo();
		if (info.error) {
			showNotification(info.error, "error");
			return;
		}

		if (mode === "media") {
			const validation = validateSettings();
			if (!validation.valid) {
				showNotification("Select at least one component", "error");
				return;
			}
		}

		if (window._ytdlpUpdateTooltip) window._ytdlpUpdateTooltip();

		const content = generatePythonScript(
			info.url,
			info.filename,
			info.cookieFile,
			mode,
			getDeletePyAfterRun(),
			getDeleteCookieAfterRun(),
		);
		const scriptFilename = `dl_${info.filename}.py`;

		try {
			const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
			const blobUrl = URL.createObjectURL(blob);
			const a = Object.assign(document.createElement("a"), {
				href: blobUrl,
				download: scriptFilename,
			});
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(blobUrl);
			showNotification("⬇ Downloading .py", "info");
		} catch (e) {
			console.error("[yt-dlp] Download failed:", e);
			showNotification("Download failed", "error");
		}

		// Auto-export cookies alongside the Python script if enabled
		if (getAutoExportCookies()) {
			// Small delay so the .py download triggers first, then the cookie file
			setTimeout(() => {
				exportCookies(window.location.hostname, true).then((ok) => {
					if (ok) {
						showNotification("⬇ .py + 🍪 cookies exported", "info");
					}
				});
			}, 150);
		}
	}

	//================================================================================
	// VISIBILITY & SPA LOGIC
	//================================================================================

	function shouldBeVisible() {
		return (
			!STATE.hidden && (!siteCondition || siteCondition(window.location.href))
		);
	}

	function updateVisibility() {
		if (containerElement) {
			containerElement.classList.toggle("hidden", !shouldBeVisible());
		}
	}

	function handleUrlChange() {
		if (window.location.href !== STATE.lastUrl) {
			STATE.hidden = false;
			STATE.lastUrl = window.location.href;
			updateVisibility();
		}
	}

	function startSPAMonitoring() {
		["pushState", "replaceState"].forEach((method) => {
			const original = history[method];
			history[method] = function (...args) {
				const result = original.apply(this, args);
				setTimeout(handleUrlChange, 0);
				return result;
			};
		});
		["popstate", "hashchange"].forEach((event) => {
			window.addEventListener(event, () => setTimeout(handleUrlChange, 0));
		});
		STATE.checkInterval = setInterval(handleUrlChange, 500);
	}

	//================================================================================
	// STYLES
	//================================================================================

	function getStyles() {
		const {
			size,
			iconStyle,
			position: pos,
			opacity,
			scale,
			zIndex,
		} = CONFIG_UI.button;
		const iconSize = size - 4;

		return `
            :host { all: initial; }
            * { box-sizing: border-box; }

            .ytdlp-container {
                position: fixed;
                ${pos.vertical}: ${pos.offsetY}px;
                ${pos.horizontal}: ${pos.offsetX}px;
                z-index: ${zIndex};
                pointer-events: auto;
                user-select: none;
            }

            .ytdlp-container.hidden { display: none !important; }

            .ytdlp-btn {
                position: relative;
                width: ${size}px;
                height: ${size}px;
                background: transparent;
                border: none;
                cursor: pointer;
                opacity: ${opacity.default};
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 0;
                margin: 0;
                transform: scale(${scale.default});
                touch-action: manipulation;
                -webkit-tap-highlight-color: transparent;
            }

            .ytdlp-btn[data-hover="true"] { opacity: ${opacity.hover}; transform: scale(${scale.hover}); }

            .ytdlp-icon-container {
                display: flex;
                align-items: center;
                justify-content: center;
                width: ${size}px;
                height: ${size}px;
                border-radius: ${iconStyle.background.enabled ? iconStyle.background.borderRadius : "0"};
                background-color: ${iconStyle.background.enabled ? iconStyle.background.color : "transparent"};
                pointer-events: none;
            }

            .ytdlp-icon {
                width: ${iconSize}px;
                height: ${iconSize}px;
                display: block;
                pointer-events: none;
                ${iconStyle.shadow.enabled ? `filter: drop-shadow(0 0 ${iconStyle.shadow.blur}px ${iconStyle.shadow.color}) drop-shadow(0 0 ${iconStyle.shadow.blur * 0.5}px ${iconStyle.shadow.color});` : ""}
            }

            .ytdlp-btn::after {
                content: attr(data-tooltip);
                position: absolute;
                ${pos.horizontal === "right" ? "right" : "left"}: ${size + 8}px;
                ${pos.vertical === "bottom" ? "bottom" : "top"}: 0;
                background: rgba(30, 30, 30, 0.95);
                color: #fff;
                padding: 8px 12px;
                border-radius: 6px;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                font-size: 12px;
                line-height: 1.5;
                white-space: pre;
                pointer-events: none;
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.15s ease, visibility 0.15s ease;
                box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                z-index: ${zIndex + 1};
            }

            .ytdlp-btn[data-hover="true"]::after { opacity: 1; visibility: visible; }
        `;
	}

	//================================================================================
	// FLOATING BUTTON
	//================================================================================

	function addFloatingDownloadButton() {
		if (!document.body) return;

		try {
			const shadowHost = document.createElement("div");
			shadowHost.id = "ytdlp-downloader-host";
			Object.assign(shadowHost.style, {
				position: "fixed",
				top: "0",
				left: "0",
				width: "0",
				height: "0",
				overflow: "visible",
				zIndex: CONFIG_UI.button.zIndex.toString(),
				pointerEvents: "none",
				userSelect: "none",
			});

			shadowRoot = shadowHost.attachShadow({ mode: "closed" });
			shadowRoot.appendChild(
				Object.assign(document.createElement("style"), {
					textContent: getStyles(),
				}),
			);

			containerElement = Object.assign(document.createElement("div"), {
				className: "ytdlp-container",
			});

			const btn = Object.assign(document.createElement("div"), {
				className: "ytdlp-btn",
			});

			const updateTooltip = () => {
				const videoOut = getVideoOutput();
				const audioOut = getAudioOutput();
				const subsOut = getSubsOutput();

				const parts = [];
				if (videoOut !== "none") {
					const codecSuffix =
						isYouTubeDomain() && getVideoCodec() !== "default"
							? ` [${getLabel(VIDEO_CODECS, getVideoCodec())}]`
							: "";
					parts.push(
						`Video: ${getLabel(VIDEO_QUALITIES, getVideoQuality())}${codecSuffix} [${getLabel(OUTPUT_MODES, videoOut)}]`,
					);
				}
				if (audioOut !== "none") {
					const audioCodecSuffix =
						getAudioCodec() !== "auto"
							? ` [${getLabel(AUDIO_CODECS, getAudioCodec())}]`
							: "";
					parts.push(
						`Audio: ${getLabel(AUDIO_QUALITIES, getAudioQuality())}${audioCodecSuffix} [${getLabel(OUTPUT_MODES, audioOut)}]`,
					);
				}
				if (subsOut !== "none") {
					parts.push(
						`Subs: ${getLabel(SUBTITLE_FORMATS, getSubsFormat())} [${getLabel(OUTPUT_MODES, subsOut)}]`,
					);
				}
				if (parts.length === 0) {
					parts.push("(Nothing selected)");
				}

				// Add container preference if MP4 selected
				if (getPreferMp4()) {
					parts.push("Container: MP4");
				}

				btn.setAttribute(
					"data-tooltip",
					[
						"𝘆𝘁-𝗱𝗹𝗽 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱𝗲𝗿",
						"",
						...parts,
						"",
						"Click: Download",
						"Right-click: Options",
						"Double-click: Hide 5s",
					].join("\n"),
				);
			};

			updateTooltip();
			window._ytdlpUpdateTooltip = updateTooltip;

			btn.addEventListener("mouseenter", () => repositionTooltip(btn));
			btn.addEventListener("mouseleave", () =>
				btn.classList.remove("ytdlp-tooltip-right"),
			);

			const iconContainer = Object.assign(document.createElement("div"), {
				className: "ytdlp-icon-container",
			});
			const iconSvg = document.createElementNS(
				"http://www.w3.org/2000/svg",
				"svg",
			);
			const attrs = [
				["class", "ytdlp-icon"],
				["viewBox", "0 0 24 24"],
				["fill", "none"],
				["stroke", "#555"],
				["stroke-width", "2"],
				["stroke-linecap", "round"],
				["stroke-linejoin", "round"],
			];
			attrs.forEach(([name, value]) => {
				iconSvg.setAttribute(name, value);
			});

			const rect = document.createElementNS(
				"http://www.w3.org/2000/svg",
				"rect",
			);
			[
				["x", "2"],
				["y", "6"],
				["width", "14"],
				["height", "12"],
				["rx", "2"],
				["ry", "2"],
			].forEach(([k, v]) => {
				rect.setAttribute(k, v);
			});

			const polygon = document.createElementNS(
				"http://www.w3.org/2000/svg",
				"polygon",
			);
			polygon.setAttribute("points", "22 8 16 12 22 16 22 8");

			iconSvg.append(rect, polygon);
			iconContainer.appendChild(iconSvg);
			btn.appendChild(iconContainer);
			containerElement.appendChild(btn);

			ContextMenu.init();
			shadowRoot.appendChild(containerElement);

			document.body.appendChild(shadowHost);

			// Notification lives in its own shadow host, appended AFTER the
			// context-menu host so it paints on the topmost layer.
			const notifHost = document.createElement("div");
			notifHost.id = "ytdlp-notification-host";
			Object.assign(notifHost.style, {
				position: "fixed",
				top: "0",
				left: "0",
				width: "0",
				height: "0",
				overflow: "visible",
				zIndex: "2147483647",
				pointerEvents: "none",
			});
			notificationShadowRoot = notifHost.attachShadow({ mode: "closed" });

			const notifStyle = document.createElement("style");
			const pos = CONFIG_UI.button.position;
			const btnSize = CONFIG_UI.button.size;
			notifStyle.textContent = `
				:host { all: initial; }
				.ytdlp-notification {
					position: fixed;
					${pos.vertical}: ${pos.offsetY + btnSize + 10}px;
					${pos.horizontal}: ${pos.offsetX}px;
					padding: 8px 16px;
					color: white;
					border-radius: 6px;
					font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
					font-size: 13px;
					font-weight: 500;
					z-index: 2147483647;
					box-shadow: 0 3px 12px rgba(0,0,0,0.25);
					opacity: 0;
					transform: translateY(10px);
					transition: opacity 0.3s, transform 0.3s;
					pointer-events: none;
				}
				.ytdlp-notification.show { opacity: 1; transform: translateY(0); }
				.ytdlp-notification[data-type="success"] { background: #4CAF50; border: 1px solid #388E3C; }
				.ytdlp-notification[data-type="error"] { background: #f44336; border: 1px solid #c62828; }
				.ytdlp-notification[data-type="info"] { background: #2196F3; border: 1px solid #1565C0; }
				.ytdlp-notification[data-type="warning"] { background: #FF9800; border: 1px solid #EF6C00; }
			`;
			notificationShadowRoot.appendChild(notifStyle);

			notificationElement = Object.assign(document.createElement("div"), {
				className: "ytdlp-notification",
			});
			notificationElement.setAttribute("data-type", "info");
			notificationShadowRoot.appendChild(notificationElement);

			document.body.appendChild(notifHost);

			//================================================================================
			// INTERACTION HANDLERS
			//================================================================================

			let lastClickTime = 0,
				hideTimeout = null;
			let hoverCheckInterval = null,
				lastMouseX = 0,
				lastMouseY = 0,
				isHovering = false;

			const setAttr = (attr, val) =>
				btn.setAttribute(`data-${attr}`, val ? "true" : "false");
			const setHover = (val) => {
				if (isHovering !== val) {
					isHovering = val;
					setAttr("hover", val);
				}
			};

			const isInsideButton = (x, y) => {
				try {
					const r = btn.getBoundingClientRect();
					return (
						x >= r.left - 2 &&
						x <= r.right + 2 &&
						y >= r.top - 2 &&
						y <= r.bottom + 2
					);
				} catch (_e) {
					return false;
				}
			};

			const onGlobalMouseMove = (e) => {
				lastMouseX = e.clientX;
				lastMouseY = e.clientY;
			};

			const startHoverTracking = () => {
				if (hoverCheckInterval) return;
				document.addEventListener("mousemove", onGlobalMouseMove, {
					passive: true,
				});
				hoverCheckInterval = setInterval(() => {
					if (!isInsideButton(lastMouseX, lastMouseY)) {
						setHover(false);
						stopHoverTracking();
					}
				}, CONFIG_UI.timing.hoverCheckInterval);
			};

			const stopHoverTracking = () => {
				if (hoverCheckInterval) {
					clearInterval(hoverCheckInterval);
					hoverCheckInterval = null;
				}
				document.removeEventListener("mousemove", onGlobalMouseMove);
			};

			btn.addEventListener("mouseenter", (e) => {
				lastMouseX = e.clientX;
				lastMouseY = e.clientY;
				setHover(true);
				startHoverTracking();
			});

			btn.addEventListener("click", (e) => {
				e.preventDefault();
				const now = Date.now();
				const timeSinceLastClick = now - lastClickTime;
				lastClickTime = now;

				if (ContextMenu.isVisible()) {
					ContextMenu.hide();
					return;
				}

				// Double-click to hide
				if (timeSinceLastClick < CONFIG_UI.timing.doubleClickThreshold) {
					window.getSelection?.().removeAllRanges();
					STATE.hidden = true;
					stopHoverTracking();
					setHover(false);
					updateVisibility();
					clearTimeout(hideTimeout);
					hideTimeout = setTimeout(() => {
						STATE.hidden = false;
						updateVisibility();
					}, CONFIG_UI.timing.hideTemporarilyDuration);
					return;
				}

				// Single click - download with current settings
				executeDownload("media");
			});

			btn.addEventListener("contextmenu", (e) => {
				e.preventDefault();
				e.stopPropagation();
				ContextMenu.show(e.clientX, e.clientY, (mode) => executeDownload(mode));
			});

			// Window-level contextmenu interceptor (capture phase)
			// This bypasses shadow DOM event routing issues on sites like TikTok
			window.addEventListener(
				"contextmenu",
				(e) => {
					try {
						const btnRect = btn.getBoundingClientRect();
						// Check if right-click is within our button bounds (with small padding)
						if (
							e.clientX >= btnRect.left - 2 &&
							e.clientX <= btnRect.right + 2 &&
							e.clientY >= btnRect.top - 2 &&
							e.clientY <= btnRect.bottom + 2
						) {
							e.preventDefault();
							e.stopPropagation();
							e.stopImmediatePropagation();
							ContextMenu.show(e.clientX, e.clientY, (mode) =>
								executeDownload(mode),
							);
							return false;
						}
					} catch (_err) {
						// Ignore - button may not be ready
					}
				},
				{ capture: true },
			);

			window.addEventListener("beforeunload", stopHoverTracking);

			updateVisibility();
			startSPAMonitoring();
			console.log("[yt-dlp Downloader] Initialized - Python edition");
		} catch (e) {
			console.error("[yt-dlp] Failed to initialize:", e);
		}
	}

	//================================================================================
	// INIT
	//================================================================================

	if (document.body) addFloatingDownloadButton();
	else document.addEventListener("DOMContentLoaded", addFloatingDownloadButton);
})();
