// ==UserScript==
// @name         No Tooltips
// @namespace    http://tampermonkey.net
// @version      1.0
// @description  Disables native title tooltips and common CSS tooltips
// @author       You
// @match        *://*/*
// @grant        GM_addStyle
// @run-at       document-start
// ==/UserScript==

(function() {
    const kill = (node) => {
        if (node.title) node.title = '';
        if (node.querySelectorAll) {
            node.querySelectorAll('[title]').forEach(el => el.title = '');
        }
    };
    // Kill existing
    kill(document);
    // Watch for new ones
    new MutationObserver(mutations => {
        mutations.forEach(m => m.addedNodes.forEach(kill));
    }).observe(document, {childList: true, subtree: true});
})();
